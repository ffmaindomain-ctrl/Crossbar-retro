package com.crossbar.retro

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class SheetOption(val label: String, val sub: String? = null, val danger: Boolean = false, val action: (() -> Unit)? = null)
class Sheet(val title: String, val text: String? = null, val options: List<SheetOption>, val onCancel: (() -> Unit)? = null)

/**
 * The options panel that slides in from the right, like the triangle menu.
 * Works by touch, d-pad and controller. Sits on top of everything else.
 */
class SheetView(ctx: Context) : View(ctx) {

    private val dp = resources.displayMetrics.density
    private var sheet: Sheet? = null
    private var sel = 0
    private var slide = 0f          // 0 hidden .. 1 shown
    private var target = 0f
    private var scroll = 0f
    private var maxScroll = 0f
    private val queue = ArrayDeque<Sheet>()

    private val light = Typeface.create("sans-serif-light", Typeface.NORMAL)
    private val regular = Typeface.create("sans-serif", Typeface.NORMAL)
    private val titleP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 21 * dp; typeface = regular }
    private val textP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(170, 225, 233, 248); textSize = 14.5f * dp; typeface = light }
    private val optP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 17.5f * dp; typeface = light }
    private val subP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(120, 225, 233, 248); textSize = 13 * dp; typeface = light }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp; color = Color.argb(40, 225, 233, 248) }

    private val rows = mutableListOf<RectF>()
    var onShownChanged: ((Boolean) -> Unit)? = null

    val isShowing get() = sheet != null

    fun show(s: Sheet) {
        if (sheet != null && target == 1f) { sheet = s; sel = 0; scroll = 0f; invalidate(); return }
        sheet = s; sel = 0; scroll = 0f; target = 1f
        visibility = VISIBLE
        onShownChanged?.invoke(true)
        invalidate()
    }

    /** Shows sheets one after another (used when several imported files need a console). */
    fun enqueue(s: Sheet) { if (sheet == null) show(s) else queue.addLast(s) }

    private fun close(cancelled: Boolean) {
        val s = sheet
        sheet = null; target = 0f
        if (cancelled) s?.onCancel?.invoke()
        settle()
    }

    /** After a sheet closes: show the next queued one, or report that the panel is gone. */
    private fun settle() {
        if (sheet == null && queue.isNotEmpty()) { show(queue.removeFirst()); return }
        if (sheet == null) onShownChanged?.invoke(false)
        invalidate()
    }

    fun dismiss() { queue.clear(); if (sheet != null) close(false) }

    private fun pick(i: Int) {
        val o = sheet?.options?.getOrNull(i) ?: return
        sheet = null; target = 0f
        o.action?.invoke()   // may open another sheet
        settle()
    }

    /** d-pad / controller commands: up, down, ok, back. Returns true if handled. */
    fun command(cmd: String): Boolean {
        val s = sheet ?: return false
        when (cmd) {
            "up" -> { sel = (sel - 1 + s.options.size) % max(1, s.options.size); ensureVisible() }
            "down" -> { sel = (sel + 1) % max(1, s.options.size); ensureVisible() }
            "ok" -> pick(sel)
            "back", "opts" -> close(true)
        }
        invalidate(); return true
    }

    private fun ensureVisible() {
        val r = rows.getOrNull(sel) ?: return
        val top = panelTop(); val bottom = height - 24 * dp
        if (r.top < top) scroll -= top - r.top
        if (r.bottom > bottom) scroll += r.bottom - bottom
        scroll = scroll.coerceIn(0f, maxScroll)
    }

    private fun panelWidth() = min(400 * dp, width * 0.88f)
    private fun panelTop() = 24 * dp

    override fun onDraw(c: Canvas) {
        slide += (target - slide) * 0.3f
        if (abs(target - slide) < 0.01f) slide = target
        if (slide == 0f && sheet == null) { visibility = GONE; return }

        val pw = panelWidth()
        val left = width - pw * slide
        fill.shader = null
        fill.color = Color.argb((90 * slide).toInt(), 0, 0, 0)
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fill)

        fill.shader = LinearGradient(left, 0f, left + pw * 0.35f, 0f,
            Color.argb(150, 6, 12, 26), Color.argb(225, 6, 12, 26), Shader.TileMode.CLAMP)
        c.drawRect(left, 0f, width.toFloat(), height.toFloat(), fill)
        fill.shader = null
        c.drawLine(left, 0f, left, height.toFloat(), line)

        val s = sheet ?: run { if (slide > 0f) postInvalidateOnAnimation(); return }
        val pad = 28 * dp
        val x = left + pad
        val w = (pw - pad * 2).toInt().coerceAtLeast(50)

        // measure content to centre it vertically when it fits
        val titleL = StaticLayout.Builder.obtain(s.title, 0, s.title.length, titleP, w).build()
        val textL = s.text?.let { StaticLayout.Builder.obtain(it, 0, it.length, textP, w).setLineSpacing(0f, 1.2f).build() }
        val rowH = 54 * dp
        val subRowH = 70 * dp
        var contentH = titleL.height + 8 * dp + (textL?.height?.plus(16 * dp) ?: 8 * dp)
        s.options.forEach { contentH += if (it.sub != null) subRowH else rowH }
        val avail = height - 48 * dp
        maxScroll = max(0f, contentH - avail)
        var y = if (contentH < avail) (height - contentH) / 2f else panelTop() - scroll

        c.save(); c.translate(x, y); titleL.draw(c); c.restore()
        y += titleL.height + 8 * dp
        if (textL != null) { c.save(); c.translate(x, y); textL.draw(c); c.restore(); y += textL.height + 16 * dp } else y += 8 * dp

        rows.clear()
        s.options.forEachIndexed { i, o ->
            val h = if (o.sub != null) subRowH else rowH
            val r = RectF(x - 12 * dp, y, x + w + 4 * dp, y + h - 4 * dp)
            rows.add(r)
            if (i == sel) {
                fill.shader = LinearGradient(r.left, 0f, r.right, 0f, Color.argb(46, 255, 255, 255), Color.argb(6, 255, 255, 255), Shader.TileMode.CLAMP)
                c.drawRoundRect(r, 6 * dp, 6 * dp, fill); fill.shader = null
            }
            optP.color = if (o.danger) Color.rgb(255, 140, 125) else Color.WHITE
            val label = TextUtils.ellipsize(o.label, optP, w.toFloat(), TextUtils.TruncateAt.END).toString()
            val ty = if (o.sub != null) r.top + 28 * dp else r.centerY() + optP.textSize * 0.35f
            c.drawText(label, x, ty, optP)
            if (o.sub != null) {
                val sub = TextUtils.ellipsize(o.sub, subP, w.toFloat(), TextUtils.TruncateAt.END).toString()
                c.drawText(sub, x, ty + 22 * dp, subP)
            }
            y += h
        }
        if (slide != target) postInvalidateOnAnimation()
    }

    private var downY = 0f
    private var downScroll = 0f
    private var dragging = false

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (sheet == null) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downY = e.y; downScroll = scroll; dragging = false }
            MotionEvent.ACTION_MOVE -> {
                if (abs(e.y - downY) > 10 * dp) dragging = true
                if (dragging && maxScroll > 0) { scroll = (downScroll - (e.y - downY)).coerceIn(0f, maxScroll); invalidate() }
            }
            MotionEvent.ACTION_UP -> {
                if (!dragging) {
                    if (e.x < width - panelWidth()) { close(true) }
                    else {
                        val i = rows.indexOfFirst { it.contains(e.x, e.y) }
                        if (i >= 0) { sel = i; invalidate(); pick(i) }
                    }
                }
            }
        }
        return true
    }
}
