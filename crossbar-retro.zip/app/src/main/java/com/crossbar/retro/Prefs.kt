package com.crossbar.retro

import android.content.Context
import android.graphics.Color

data class XTheme(val name: String, val top: Int, val bottom: Int, val wave: Int)

object Themes {
    val all = listOf(
        XTheme("Deep blue", Color.rgb(11, 31, 69), Color.rgb(2, 6, 15), Color.rgb(120, 170, 255)),
        XTheme("Violet dusk", Color.rgb(42, 20, 80), Color.rgb(7, 3, 15), Color.rgb(190, 150, 255)),
        XTheme("Teal", Color.rgb(6, 60, 64), Color.rgb(1, 10, 12), Color.rgb(110, 230, 220)),
        XTheme("Ember", Color.rgb(74, 22, 8), Color.rgb(13, 4, 2), Color.rgb(255, 160, 110)),
        XTheme("Moss", Color.rgb(29, 58, 18), Color.rgb(5, 11, 3), Color.rgb(170, 230, 120)),
        XTheme("Graphite", Color.rgb(43, 47, 56), Color.rgb(6, 7, 9), Color.rgb(210, 215, 230)),
    )
}

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("crossbar", Context.MODE_PRIVATE)

    var theme: Int
        get() = sp.getInt("theme", 0).coerceIn(0, Themes.all.size - 1)
        set(v) = sp.edit().putInt("theme", v).apply()
    var waves: Boolean
        get() = sp.getBoolean("waves", true)
        set(v) = sp.edit().putBoolean("waves", v).apply()
    /** 0.2 .. 1.0 */
    var padOpacity: Float
        get() = sp.getFloat("padOpacity", 0.6f)
        set(v) = sp.edit().putFloat("padOpacity", v).apply()
    /** 0.8 .. 1.3 */
    var padScale: Float
        get() = sp.getFloat("padScale", 1f)
        set(v) = sp.edit().putFloat("padScale", v).apply()
    var haptics: Boolean
        get() = sp.getBoolean("haptics", true)
        set(v) = sp.edit().putBoolean("haptics", v).apply()

    val xtheme get() = Themes.all[theme]

    /** Chosen emulator engine per console, e.g. "pcsx_rearmed" for PlayStation. */
    fun core(console: String): String? = sp.getString("core_$console", null)
    fun setCore(console: String, core: String) = sp.edit().putString("core_$console", core).apply()

    /** Chosen external app per console, stored as "package/activity". */
    fun externalApp(console: String): String? = sp.getString("ext_$console", null)
    fun setExternalApp(console: String, id: String?) = sp.edit().putString("ext_$console", id).apply()
}
