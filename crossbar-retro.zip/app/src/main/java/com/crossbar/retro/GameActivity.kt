package com.crossbar.retro

import android.content.pm.ActivityInfo
import android.graphics.Color
import android.hardware.input.InputManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.GLRetroViewData
import com.swordfish.libretrodroid.ShaderConfig
import com.swordfish.libretrodroid.Variable
import com.swordfish.libretrodroid.ViewportAlignment
import kotlinx.coroutines.launch
import java.io.File
import java.util.zip.ZipInputStream

class GameActivity : ComponentActivity(), PadListener {

    companion object { const val EXTRA_GAME = "game" }

    private lateinit var lib: Library
    private lateinit var prefs: Prefs
    private lateinit var game: Game
    private lateinit var console: Console
    private lateinit var root: FrameLayout
    private lateinit var sheet: SheetView
    private var retro: GLRetroView? = null
    private var pad: TouchPadView? = null
    private var loading: TextView? = null

    private var started = false       // first frame drawn
    private var coreName = ""
    private var menuOpen = false
    private var fastForward = false
    private var padHidden = false
    private val ui = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lib = Library.get(this)
        prefs = Prefs(this)
        val g = lib.game(intent.getLongExtra(EXTRA_GAME, -1))
        val c = g?.let { Consoles.byId[it.console] }
        if (g == null || c == null || !File(g.path).exists()) { finish(); return }
        game = g; console = c

        requestedOrientation = if (console.portrait) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                               else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE

        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        sheet = SheetView(this).apply { visibility = View.GONE }
        loading = TextView(this).apply {
            text = "Starting ${game.title}…"; setTextColor(Color.argb(200, 255, 255, 255)); textSize = 16f; gravity = Gravity.CENTER
        }
        root.addView(loading, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        // keep the picture and the controls clear of the camera cut-out
        Screen.immersive(this, root) { l, t, r, b -> root.setPadding(l, t, r, b) }

        // PSP needs its font and shader files in the system folder before it starts
        Thread {
            if (console.id == "psp") prepareAssets("ppsspp.zip", File(lib.systemDir, "PPSSPP"))
            if (console.id == "gc" || console.id == "wii") prepareAssets("dolphin.zip", lib.systemDir)
            runOnUiThread { if (!isFinishing) startEmulation() }
        }.start()
        lib.markPlayed(game.id)
    }

    private fun prepareAssets(asset: String, dest: File) {
        val marker = File(dest, ".ready-$asset")
        if (marker.exists()) return
        try {
            dest.mkdirs()
            (try { assets.open(asset) } catch (_: Exception) { return }).use { ins ->
                ZipInputStream(ins).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        val parts = e.name.split('/').filter { it.isNotEmpty() && it != ".." }
                        val out = File(dest, parts.joinToString("/"))
                        if (e.isDirectory) out.mkdirs() else { out.parentFile?.mkdirs(); out.outputStream().use { z.copyTo(it) } }
                        e = z.nextEntry
                    }
                }
            }
            marker.writeText("1")
        } catch (_: Exception) { }
    }

    private fun startEmulation() {
        val core = console.coreFile(this, prefs.core(console.id)) ?: run { finish(); return }
        coreName = core.name.removePrefix("lib").removeSuffix("_libretro_android.so")
        val sram = lib.sramFile(game).takeIf { it.exists() && it.length() > 0 }?.readBytes()
        val saves = File(lib.savesDir, console.id).apply { mkdirs() }

        val data = GLRetroViewData(this).apply {
            coreFilePath = core.absolutePath
            gameFilePath = game.path
            systemDirectory = lib.systemDir.absolutePath
            savesDirectory = saves.absolutePath
            variables = coreVariables()
            saveRAMState = sram
            shader = if (console.portrait) ShaderConfig.Sharp else ShaderConfig.Default
            viewportAlignment = if (console.portrait) ViewportAlignment.TOP else ViewportAlignment.CENTER
            rumbleEventsEnabled = false
            preferLowLatencyAudio = true
        }
        val view = GLRetroView(this, data)
        retro = view
        lifecycle.addObserver(view)
        root.addView(view, 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val p = TouchPadView(this, console.pad, this).apply {
            aspect = console.aspect; opacity = prefs.padOpacity; scale = prefs.padScale; haptics = prefs.haptics
        }
        pad = p
        root.addView(p, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(sheet, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.requestApplyInsets()
        updatePadVisibility()

        lifecycleScope.launch {
            view.getGLRetroEvents().collect { ev ->
                if (ev is GLRetroView.GLRetroEvents.FrameRendered && !started) {
                    started = true
                    loading?.let { root.removeView(it) }; loading = null
                    onFirstFrame()
                }
            }
        }
        lifecycleScope.launch {
            view.getGLRetroErrors().collect { code -> showError(code) }
        }
    }

    private fun coreVariables(): Array<Variable> = when (coreName) {
        "melonds" -> arrayOf(Variable("melonds_touch_mode", "Touch"))
        // dynamic recompiler on, no fake frame skipping, real BIOS when there is one
        "pcsx_rearmed" -> arrayOf(Variable("pcsx_rearmed_drc", "enabled"), Variable("pcsx_rearmed_frameskip_type", "disabled"),
            Variable("pcsx_rearmed_show_bios_bootlogo", "disabled"))
        "swanstation" -> arrayOf(Variable("swanstation_GPU_Renderer", "Software"))
        "citra" -> arrayOf(Variable("citra_layout_option", "Default Top-Bottom Screen"))
        else -> arrayOf()
    }

    private fun onFirstFrame() {
        // give the PlayStation an analog DualShock so the touch sticks work
        if (console.pad == PadLayout.PSX) {
            // talk to the core on its own thread; calling it from the screen thread can crash it
            val v = retro ?: return
            v.queueEvent {
                try {
                    v.getControllers().getOrNull(0)?.firstOrNull { it.description?.contains("dualshock", true) == true }
                        ?.let { v.setControllerType(0, it.id) }
                } catch (_: Exception) { }
            }
        }
    }

    private fun showError(code: Int) {
        val msg = when (code) {
            GLRetroView.ERROR_LOAD_LIBRARY -> "The ${console.name} emulator could not start on this phone."
            GLRetroView.ERROR_LOAD_GAME -> when {
                coreName == "mednafen_psx" && !lib.hasBios(console) -> "Beetle PSX needs a PlayStation BIOS. Import scph5501.bin, or switch engine from the game's options."
                console.disc -> "This disc image could not be opened. If it is a .bin, import it together with its .cue file, or use a single .chd or .pbp. You can also try another engine from the game's options."
                else -> "This game file could not be opened. It may be damaged, encrypted, or for a different console."
            }
            GLRetroView.ERROR_GL_NOT_COMPATIBLE -> "This phone's graphics chip is not supported by the ${console.name} emulator."
            else -> "The emulator stopped unexpectedly."
        }
        pad?.visibility = View.GONE
        sheet.show(Sheet("Could not run ${game.title}", msg, listOf(SheetOption("Back to menu") { finish() }), onCancel = { finish() }))
    }

    // ---------- controller detection ----------

    private val inputListener = object : InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(id: Int) = updatePadVisibility()
        override fun onInputDeviceRemoved(id: Int) = updatePadVisibility()
        override fun onInputDeviceChanged(id: Int) = updatePadVisibility()
    }

    private fun hasController(): Boolean = InputDevice.getDeviceIds().any { id ->
        val d = InputDevice.getDevice(id) ?: return@any false
        !d.isVirtual && (d.sources and InputDevice.SOURCE_GAMEPAD == InputDevice.SOURCE_GAMEPAD ||
            d.sources and InputDevice.SOURCE_JOYSTICK == InputDevice.SOURCE_JOYSTICK)
    }

    private fun updatePadVisibility() {
        val show = !padHidden && !hasController()
        pad?.visibility = if (show) View.VISIBLE else View.GONE
    }

    // ---------- pause menu ----------

    private fun pauseEmu() {
        val v = retro ?: return
        v.audioEnabled = false
        v.onPause()
    }

    private fun resumeEmu() {
        val v = retro ?: return
        v.onResume()
        v.audioEnabled = true
    }

    override fun onMenu() {
        if (menuOpen || !started) return
        menuOpen = true
        pad?.releaseAll()
        pauseEmu()
        val hasState = lib.stateFile(game, 1).exists()
        sheet.show(Sheet(game.title, console.name, listOfNotNull(
            SheetOption("Resume") { closeMenu() },
            SheetOption("Save state", "Snapshot of this exact moment") { saveState(); closeMenu() },
            if (hasState) SheetOption("Load state", "Go back to your snapshot") { loadState(); closeMenu() } else null,
            SheetOption(if (fastForward) "Normal speed" else "Fast forward", if (fastForward) null else "Runs at double speed") {
                fastForward = !fastForward; retro?.frameSpeed = if (fastForward) 2 else 1; closeMenu()
            },
            SheetOption(if (padHidden) "Show touch controls" else "Hide touch controls") { padHidden = !padHidden; updatePadVisibility(); closeMenu() },
            SheetOption("Restart game") { retro?.reset(false); closeMenu() },
            SheetOption("Quit to menu", "In-game saves are kept") { quit() },
        ), onCancel = { closeMenu() }))
    }

    private fun closeMenu() {
        if (!menuOpen) return
        menuOpen = false
        resumeEmu()
    }

    private fun saveState() {
        try {
            val bytes = retro?.serializeState(false) ?: return
            if (bytes.isNotEmpty()) { lib.stateFile(game, 1).writeBytes(bytes); toast("State saved") }
            else toast("This emulator cannot save states")
        } catch (_: Exception) { toast("Could not save state") }
    }

    private fun loadState() {
        try {
            val f = lib.stateFile(game, 1)
            val ok = retro?.unserializeState(f.readBytes(), false) ?: false
            toast(if (ok) "State loaded" else "Could not load that state")
        } catch (_: Exception) { toast("Could not load state") }
    }

    /** Writes the game's own save memory. Only call while the emulation thread is paused. */
    private fun saveSram() {
        if (!started) return
        try {
            val bytes = retro?.serializeSRAM(false) ?: return
            if (bytes.isNotEmpty()) lib.sramFile(game).writeBytes(bytes)
        } catch (_: Exception) { }
    }

    private fun quit() {
        if (!menuOpen) pauseEmu()
        saveSram()
        menuOpen = false
        finish()
    }

    private var toastView: TextView? = null
    private fun toast(msg: String) {
        toastView?.let { root.removeView(it) }
        val t = TextView(this).apply {
            text = msg; setTextColor(Color.WHITE); textSize = 14f
            setBackgroundColor(Color.argb(200, 6, 12, 26)); setPadding(36, 20, 36, 20)
        }
        root.addView(t, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = 60 })
        toastView = t
        ui.postDelayed({ root.removeView(t); if (toastView === t) toastView = null }, 1800)
    }

    // ---------- lifecycle ----------

    override fun onResume() {
        super.onResume()
        Screen.immersive(this, null, null)
        getSystemService(InputManager::class.java)?.registerInputDeviceListener(inputListener, ui)
        updatePadVisibility()
        if (menuOpen) pauseEmu() // the view resumes itself with the activity; keep it paused under the menu
    }

    override fun onPause() {
        super.onPause() // the emulator view pauses itself here
        getSystemService(InputManager::class.java)?.unregisterInputDeviceListener(inputListener)
        saveSram()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) Screen.immersive(this, null, null)
    }

    // ---------- touch pad events ----------

    override fun onKey(keyCode: Int, down: Boolean) {
        retro?.sendKeyEvent(if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, keyCode)
    }

    override fun onDpad(x: Float, y: Float) {
        retro?.sendMotionEvent(GLRetroView.MOTION_SOURCE_DPAD, x, y)
    }

    override fun onStick(right: Boolean, x: Float, y: Float) {
        retro?.sendMotionEvent(if (right) GLRetroView.MOTION_SOURCE_ANALOG_RIGHT else GLRetroView.MOTION_SOURCE_ANALOG_LEFT, x, y)
    }

    // ---------- physical controllers ----------

    private fun port(e: InputEvent?): Int = ((e?.device?.controllerNumber ?: 1) - 1).coerceAtLeast(0)

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (code == KeyEvent.KEYCODE_VOLUME_UP || code == KeyEvent.KEYCODE_VOLUME_DOWN || code == KeyEvent.KEYCODE_VOLUME_MUTE)
            return super.dispatchKeyEvent(event)
        if (sheet.isShowing) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                when (code) {
                    KeyEvent.KEYCODE_DPAD_UP -> sheet.command("up")
                    KeyEvent.KEYCODE_DPAD_DOWN -> sheet.command("down")
                    KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> sheet.command("ok")
                    KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE, KeyEvent.KEYCODE_BUTTON_MODE -> sheet.command("back")
                }
            }
            return true
        }
        if (code == KeyEvent.KEYCODE_BACK || code == KeyEvent.KEYCODE_BUTTON_MODE || code == KeyEvent.KEYCODE_ESCAPE) {
            if (event.action == KeyEvent.ACTION_UP) { if (started) onMenu() else finish() }
            return true
        }
        val v = retro ?: return super.dispatchKeyEvent(event)
        if (event.repeatCount > 0) return true
        v.sendKeyEvent(event.action, code, port(event))
        return true
    }

    override fun dispatchGenericMotionEvent(e: MotionEvent): Boolean {
        val v = retro
        if (v == null || sheet.isShowing || e.source and InputDevice.SOURCE_JOYSTICK != InputDevice.SOURCE_JOYSTICK)
            return super.dispatchGenericMotionEvent(e)
        val p = port(e)
        v.sendMotionEvent(GLRetroView.MOTION_SOURCE_DPAD, e.getAxisValue(MotionEvent.AXIS_HAT_X), e.getAxisValue(MotionEvent.AXIS_HAT_Y), p)
        v.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_LEFT, e.getAxisValue(MotionEvent.AXIS_X), e.getAxisValue(MotionEvent.AXIS_Y), p)
        v.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_RIGHT, e.getAxisValue(MotionEvent.AXIS_Z), e.getAxisValue(MotionEvent.AXIS_RZ), p)
        return true
    }
}
