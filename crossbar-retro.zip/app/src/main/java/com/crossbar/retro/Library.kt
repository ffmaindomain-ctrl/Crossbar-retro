package com.crossbar.retro

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipInputStream

data class Game(
    val id: Long,
    var console: String,
    var title: String,
    var path: String,
    val size: Long,
    val added: Long,
    var lastPlayed: Long = 0,
)

/** A picked file waiting to be copied in, with the console it goes to. */
data class PendingImport(val uri: Uri, val name: String, var console: String?)

class Library private constructor(private val ctx: Context) {

    companion object {
        @Volatile private var instance: Library? = null
        fun get(ctx: Context): Library =
            instance ?: synchronized(this) { instance ?: Library(ctx.applicationContext).also { instance = it } }
    }

    private val root: File = ctx.getExternalFilesDir(null) ?: ctx.filesDir
    val gamesDir = File(root, "games")
    val systemDir = File(ctx.filesDir, "system")
    val savesDir = File(root, "saves")
    val statesDir = File(root, "states")
    private val indexFile = File(ctx.filesDir, "library.json")

    private val list = mutableListOf<Game>()
    private var nextId = System.currentTimeMillis()

    init {
        listOf(gamesDir, systemDir, savesDir, statesDir).forEach { it.mkdirs() }
        load()
    }

    @Synchronized fun games(): List<Game> = list.toList()
    @Synchronized fun game(id: Long): Game? = list.firstOrNull { it.id == id }
    fun gamesFor(console: String) = games().filter { it.console == console }
        .sortedWith(compareByDescending<Game> { it.lastPlayed }.thenBy { it.title.lowercase() })

    @Synchronized private fun load() {
        list.clear()
        if (!indexFile.exists()) return
        try {
            val arr = JSONArray(indexFile.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val g = Game(o.getLong("id"), o.getString("console"), o.getString("title"), o.getString("path"),
                    o.optLong("size"), o.optLong("added"), o.optLong("lastPlayed"))
                if (File(g.path).exists()) list.add(g)
            }
        } catch (_: Exception) { }
    }

    @Synchronized fun save() {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("console", it.console).put("title", it.title)
                .put("path", it.path).put("size", it.size).put("added", it.added).put("lastPlayed", it.lastPlayed))
        }
        val tmp = File(indexFile.parentFile, "library.json.tmp")
        tmp.writeText(arr.toString())
        tmp.renameTo(indexFile)
    }

    @Synchronized fun markPlayed(id: Long) { game(id)?.lastPlayed = System.currentTimeMillis(); save() }

    @Synchronized fun move(id: Long, console: String) {
        val g = game(id) ?: return
        val dest = File(gamesDir, console).apply { mkdirs() }
        val src = File(g.path)
        // a single loose file moves with it; unpacked folders and cue sheets stay put
        val loose = src.parentFile?.absolutePath == File(gamesDir, g.console).absolutePath &&
            src.extension.lowercase() !in Consoles.sheetExts
        if (loose) {
            val target = File(dest, src.name)
            if (src.renameTo(target)) g.path = target.absolutePath
        }
        g.console = console
        save()
    }

    @Synchronized fun delete(id: Long) {
        val g = game(id) ?: return
        val f = File(g.path)
        val consoleDir = File(gamesDir, g.console)
        if (f.parentFile != null && f.parentFile!!.absolutePath != consoleDir.absolutePath &&
            f.parentFile!!.parentFile?.absolutePath == consoleDir.absolutePath) {
            // unpacked from an archive into its own folder
            f.parentFile!!.deleteRecursively()
        } else {
            sheetTracks(f).forEach { it.delete() }
            f.delete()
        }
        list.removeAll { it.id == id }
        save()
    }

    @Synchronized fun deleteAll() {
        gamesDir.deleteRecursively(); gamesDir.mkdirs()
        list.clear(); save()
    }

    fun totalSize() = games().sumOf { it.size }

    /** Track files listed inside a .cue or .gdi sheet. */
    private fun sheetTracks(sheet: File): List<File> {
        val ext = sheet.extension.lowercase()
        if (ext != "cue" && ext != "gdi") return emptyList()
        return try {
            sheet.readLines().mapNotNull { line ->
                val t = line.trim()
                when {
                    ext == "cue" && t.startsWith("FILE", true) -> Regex("\"(.+?)\"").find(t)?.groupValues?.get(1)
                    ext == "gdi" -> t.split(Regex("\\s+")).getOrNull(4)?.trim('"')
                    else -> null
                }
            }.map { File(sheet.parentFile, it) }
        } catch (_: Exception) { emptyList() }
    }

    // ---------- reading picked files ----------

    fun displayName(uri: Uri): String {
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) { val n = c.getString(0); if (!n.isNullOrBlank()) return n }
            }
        } catch (_: Exception) { }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "game"
    }

    /** For an archive, guess the console from the files inside it. */
    fun guessArchive(uri: Uri): String? {
        return try {
            ctx.contentResolver.openInputStream(uri)?.use { ins ->
                ZipInputStream(ins).use { z ->
                    var e = z.nextEntry
                    var found: String? = null
                    while (e != null && found == null) {
                        if (!e.isDirectory) found = Consoles.guess(e.name)?.id
                        e = z.nextEntry
                    }
                    found
                }
            }
        } catch (_: Exception) { null }
    }

    /**
     * Copies files in and registers the playable ones.
     * Runs on a background thread. Returns the games added.
     */
    fun import(items: List<PendingImport>, progress: (done: Int, total: Int, name: String) -> Unit): List<Game> {
        val added = mutableListOf<Game>()
        val touchedDirs = mutableMapOf<File, String>() // folder -> console
        val copied = mutableListOf<Pair<File, String>>()
        val buf = ByteArray(1 shl 16)
        items.forEachIndexed { idx, it ->
            val console = it.console ?: return@forEachIndexed
            progress(idx, items.size, it.name)
            val consoleDir = File(gamesDir, console).apply { mkdirs() }
            val ext = it.name.substringAfterLast('.', "").lowercase()
            try {
                if (ext == "zip") {
                    val folder = uniqueDir(consoleDir, it.name.substringBeforeLast('.'))
                    ctx.contentResolver.openInputStream(it.uri)?.use { ins ->
                        ZipInputStream(ins).use { z ->
                            var e = z.nextEntry
                            while (e != null) {
                                val safe = e.name.replace('\\', '/').split('/').filter { p -> p.isNotBlank() && p != ".." }
                                if (!e.isDirectory && safe.isNotEmpty()) {
                                    val out = File(folder, safe.last())
                                    out.outputStream().use { o ->
                                        while (true) { val n = z.read(buf); if (n <= 0) break; o.write(buf, 0, n) }
                                    }
                                    copied += out to console
                                }
                                e = z.nextEntry
                            }
                        }
                    }
                    touchedDirs[folder] = console
                } else {
                    val out = File(consoleDir, it.name)
                    ctx.contentResolver.openInputStream(it.uri)?.use { ins ->
                        out.outputStream().use { o -> ins.copyTo(o, 1 shl 16) }
                    }
                    copied += out to console
                    touchedDirs[consoleDir] = console
                }
            } catch (_: Exception) { }
        }
        progress(items.size, items.size, "")

        synchronized(this) {
            for ((file, console) in copied) {
                val c = Consoles.byId[console] ?: continue
                val ext = file.extension.lowercase()
                val siblings = copied.filter { it.first.parentFile == file.parentFile }.map { it.first.extension.lowercase() }
                val hasSheet = siblings.any { it in Consoles.sheetExts }
                if (hasSheet && Consoles.isTrack(ext)) continue
                if (hasSheet && ext in setOf("cue", "ccd") && siblings.contains("m3u")) continue
                if (ext !in c.exts && ext !in Consoles.sheetExts) continue
                if (list.any { it.path == file.absolutePath }) continue
                val size = if (ext in Consoles.sheetExts) file.parentFile?.listFiles()?.filter { f ->
                    copied.any { it.first == f } }?.sumOf { it.length() } ?: file.length() else file.length()
                val g = Game(nextId++, console, file.nameWithoutExtension, file.absolutePath, size, System.currentTimeMillis())
                list.add(g); added.add(g)
            }
            save()
        }
        return added
    }

    private fun uniqueDir(parent: File, base: String): File {
        var d = File(parent, base); var n = 2
        while (d.exists()) { d = File(parent, "$base ($n)"); n++ }
        d.mkdirs(); return d
    }

    // ---------- BIOS ----------

    fun biosFile(c: Console, name: String) = File(if (c.biosDir.isEmpty()) systemDir else File(systemDir, c.biosDir), name)

    fun installedBios(): List<Pair<Console, File>> =
        Consoles.all.flatMap { c -> c.bios.map { c to biosFile(c, it) } }.filter { it.second.exists() }
            .distinctBy { it.second.absolutePath }

    fun hasBios(c: Console) = c.bios.any { biosFile(c, it).exists() }

    fun saveBios(uri: Uri, c: Console, name: String): File? = try {
        val out = biosFile(c, name).apply { parentFile?.mkdirs() }
        ctx.contentResolver.openInputStream(uri)?.use { ins -> out.outputStream().use { ins.copyTo(it) } }
        out
    } catch (_: Exception) { null }

    // ---------- per-game save files ----------

    fun sramFile(g: Game) = File(File(savesDir, g.console).apply { mkdirs() }, "${g.id}.srm")
    fun stateFile(g: Game, slot: Int) = File(File(statesDir, g.console).apply { mkdirs() }, "${g.id}.s$slot")
}
