package com.crossbar.retro

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

interface PadListener {
    fun onKey(keyCode: Int, down: Boolean)
    fun onDpad(x: Float, y: Float)
    fun onStick(right: Boolean, x: Float, y: Float)
    fun onMenu()
}

/**
 * On-screen controller drawn for each console's real pad: Game Boy's diagonal A/B,
 * the PlayStation shapes, the Mega Drive's A-B-C row, the 3DS circle pad, and so on.
 * Touches that miss every control fall through to the game (DS/3DS touch screen).
 */
class TouchPadView(ctx: Context, private val layout: PadLayout, private val listener: PadListener) : View(ctx) {

    private sealed class Ctl(var cx: Float, var cy: Float, var r: Float) {
        open fun hit(x: Float, y: Float) = hypot(x - cx, y - cy) <= r * 1.25f
    }
    private class Btn(val label: String, val key: Int, cx: Float, cy: Float, r: Float, val pillW: Float = 0f, val pillH: Float = 0f, val face: Boolean = false) : Ctl(cx, cy, r) {
        var down = false
        override fun hit(x: Float, y: Float) =
            if (pillW > 0) abs(x - cx) <= pillW / 2 + 10 && abs(y - cy) <= pillH / 2 + 12 else super.hit(x, y)
    }
    private class Dpad(cx: Float, cy: Float, r: Float) : Ctl(cx, cy, r) { var dx = 0; var dy = 0 }
    private class Stick(val right: Boolean, cx: Float, cy: Float, r: Float) : Ctl(cx, cy, r) { var x = 0f; var y = 0f }
    private class Menu(cx: Float, cy: Float, r: Float) : Ctl(cx, cy, r)

    private val dp = resources.displayMetrics.density
    private val ctls = mutableListOf<Ctl>()
    private val owner = HashMap<Int, Ctl>()

    var opacity = 0.6f
        set(v) { field = v; invalidate() }
    var scale = 1f
        set(v) { field = v; requestLayout(); rebuild() }
    var haptics = true
    /** fraction of the height where the controls area starts in portrait (below the picture) */
    var aspect = 4f / 3f
        set(v) { field = v; rebuild() }
    var insetLeft = 0f; var insetRight = 0f; var insetBottom = 0f; var insetTop = 0f
    var zoneTop = 0f
        private set

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; typeface = Typeface.create("sans-serif", Typeface.NORMAL); textAlign = Paint.Align.CENTER }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) = rebuild()

    private fun rebuild() {
        ctls.clear(); owner.clear()
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val s = dp * scale
        val portrait = h > w
        val gl = max(insetLeft, 12 * dp); val gr = max(insetRight, 12 * dp); val gb = max(insetBottom, 10 * dp)

        val faceR: Float; val faceOff: Float; val dpadR: Float
        val dpadC: Pair<Float, Float>; val faceC: Pair<Float, Float>
        if (portrait) {
            val pic = min(w / aspect, h * 0.6f)
            zoneTop = max(pic + insetTop + 8 * dp, h * 0.42f)
            val zh = h - zoneTop - gb
            val yc = zoneTop + zh * 0.47f
            dpadR = min(w * 0.19f, 76 * s); faceR = min(w * 0.075f, 31 * s); faceOff = faceR * 1.62f
            dpadC = (w * 0.26f) to yc
            faceC = (w * 0.74f) to yc
        } else {
            zoneTop = 0f
            dpadR = 70 * s; faceR = 29 * s; faceOff = 48 * s
            dpadC = (gl + 100 * s) to (h - gb - 115 * s)
            faceC = (w - gr - 105 * s) to (h - gb - 115 * s)
        }

        fun dpad(cx: Float = dpadC.first, cy: Float = dpadC.second, r: Float = dpadR) { ctls += Dpad(cx, cy, r) }
        fun diamond(n: Pair<String, Int>, e: Pair<String, Int>, so: Pair<String, Int>, we: Pair<String, Int>) {
            val (x, y) = faceC
            ctls += Btn(n.first, n.second, x, y - faceOff, faceR, face = true)
            ctls += Btn(e.first, e.second, x + faceOff, y, faceR, face = true)
            ctls += Btn(so.first, so.second, x, y + faceOff, faceR, face = true)
            ctls += Btn(we.first, we.second, x - faceOff, y, faceR, face = true)
        }
        fun two(b: Pair<String, Int>, a: Pair<String, Int>) {
            val (x, y) = faceC; val r = faceR * 1.18f
            ctls += Btn(b.first, b.second, x - r * 1.05f, y + r * 0.55f, r, face = true)
            ctls += Btn(a.first, a.second, x + r * 1.05f, y - r * 0.55f, r, face = true)
        }
        fun row3(a: Pair<String, Int>, b: Pair<String, Int>, c: Pair<String, Int>, top: List<Pair<String, Int>> = emptyList()) {
            val (x, y) = faceC; val r = faceR; val gap = r * 2.25f
            val base = y + r * 0.6f
            ctls += Btn(a.first, a.second, x - gap, base + r * 0.45f, r, face = true)
            ctls += Btn(b.first, b.second, x, base, r, face = true)
            ctls += Btn(c.first, c.second, x + gap, base - r * 0.45f, r, face = true)
            top.forEachIndexed { i, t ->
                ctls += Btn(t.first, t.second, x + (i - 1) * gap, base - r * 2.3f - (i - 1) * r * 0.45f, r * 0.74f, face = true)
            }
        }
        val pillW = 92 * s; val pillH = 38 * s
        fun shoulders(vararg l: Pair<String, Int>, right: List<Pair<String, Int>>) {
            val y0 = if (portrait) zoneTop + 26 * s else max(insetTop, 8 * dp) + 30 * s
            l.forEachIndexed { i, p -> ctls += Btn(p.first, p.second, gl + pillW / 2 + i * (pillW + 10 * s), y0, 0f, pillW, pillH) }
            right.forEachIndexed { i, p -> ctls += Btn(p.first, p.second, w - gr - pillW / 2 - i * (pillW + 10 * s), y0, 0f, pillW, pillH) }
        }
        fun startSelect(start: String? = "START", select: String? = "SELECT") {
            val y = h - gb - 22 * s
            val sw = 78 * s; val sh = 30 * s
            if (select != null) ctls += Btn(select, KeyEvent.KEYCODE_BUTTON_SELECT, w / 2 - (if (start != null) sw * 0.62f else 0f), y, 0f, sw, sh)
            if (start != null) ctls += Btn(start, KeyEvent.KEYCODE_BUTTON_START, w / 2 + (if (select != null) sw * 0.62f else 0f), y, 0f, sw, sh)
        }
        fun sticks(left: Boolean, right: Boolean) {
            val r = 50 * s
            if (portrait) {
                if (left) ctls += Stick(false, w * 0.26f, h - gb - 70 * s, r)
                if (right) ctls += Stick(true, w * 0.74f, h - gb - 70 * s, r)
            } else {
                if (left) ctls += Stick(false, gl + 240 * s, h - gb - 62 * s, r)
                if (right) ctls += Stick(true, w - gr - 240 * s, h - gb - 62 * s, r)
            }
        }
        val A = KeyEvent.KEYCODE_BUTTON_A; val B = KeyEvent.KEYCODE_BUTTON_B
        val X = KeyEvent.KEYCODE_BUTTON_X; val Y = KeyEvent.KEYCODE_BUTTON_Y
        val L1 = KeyEvent.KEYCODE_BUTTON_L1; val R1 = KeyEvent.KEYCODE_BUTTON_R1
        val L2 = KeyEvent.KEYCODE_BUTTON_L2; val R2 = KeyEvent.KEYCODE_BUTTON_R2

        when (layout) {
            PadLayout.GB -> { dpad(); two("B" to B, "A" to A); startSelect() }
            PadLayout.GBA -> { dpad(); two("B" to B, "A" to A); shoulders("L" to L1, right = listOf("R" to R1)); startSelect() }
            PadLayout.VB -> { dpad(); two("B" to B, "A" to A); shoulders("L" to L1, right = listOf("R" to R1)); startSelect() }
            PadLayout.POKEMINI -> { dpad(); two("B" to B, "A" to A)
                ctls += Btn("C", R1, faceC.first, faceC.second + faceR * 2.6f, faceR * 0.8f, face = true); startSelect(start = "POWER", select = null) }
            PadLayout.GW -> { dpad(); two("B" to B, "A" to A); startSelect(start = "GAME", select = "TIME") }
            PadLayout.NDS -> { dpad(); diamond("X" to X, "A" to A, "B" to B, "Y" to Y); shoulders("L" to L1, right = listOf("R" to R1)); startSelect() }
            PadLayout.N3DS -> {
                val (x, y) = dpadC
                ctls += Stick(false, x, y - dpadR * 0.62f, dpadR * 0.62f)
                dpad(x, y + dpadR * 0.78f, dpadR * 0.62f)
                diamond("X" to X, "A" to A, "B" to B, "Y" to Y)
                shoulders("L" to L1, "ZL" to L2, right = listOf("R" to R1, "ZR" to R2)); startSelect()
            }
            PadLayout.PSX, PadLayout.PS2 -> { dpad(); diamond("△" to X, "○" to A, "✕" to B, "□" to Y)
                shoulders("L1" to L1, "L2" to L2, right = listOf("R1" to R1, "R2" to R2)); startSelect(); sticks(left = true, right = true) }
            PadLayout.PSP -> { dpad(); diamond("△" to X, "○" to A, "✕" to B, "□" to Y)
                shoulders("L" to L1, right = listOf("R" to R1)); startSelect(); sticks(left = true, right = false) }
            PadLayout.MD -> { dpad(); row3("A" to Y, "B" to B, "C" to A, listOf("X" to L1, "Y" to X, "Z" to R1)); startSelect(start = "START", select = "MODE") }
            PadLayout.SMS -> { dpad(); two("1" to B, "2" to A); startSelect(start = "START", select = null) }
            PadLayout.SATURN -> { dpad(); row3("A" to B, "B" to A, "C" to R1, listOf("X" to Y, "Y" to X, "Z" to L1))
                shoulders("L" to L2, right = listOf("R" to R2)); startSelect(start = "START", select = null) }
            PadLayout.DC -> { dpad(); diamond("Y" to X, "B" to A, "A" to B, "X" to Y)
                shoulders("LT" to L2, right = listOf("RT" to R2)); startSelect(start = "START", select = null); sticks(left = true, right = false) }
        }
        // menu button
        val my = if (portrait) zoneTop + 26 * s else max(insetTop, 8 * dp) + 30 * s
        ctls += Menu(w / 2f, my, 20 * s)
        invalidate()
    }

    // ---------- drawing ----------

    override fun onDraw(c: Canvas) {
        val a = (255 * opacity).toInt()
        stroke.strokeWidth = 1.6f * dp
        for (ctl in ctls) when (ctl) {
            is Dpad -> drawDpad(c, ctl, a)
            is Stick -> {
                stroke.alpha = a / 2; c.drawCircle(ctl.cx, ctl.cy, ctl.r, stroke)
                fill.alpha = a / 3
                c.drawCircle(ctl.cx + ctl.x * ctl.r * 0.6f, ctl.cy + ctl.y * ctl.r * 0.6f, ctl.r * 0.5f, fill)
                stroke.alpha = a; c.drawCircle(ctl.cx + ctl.x * ctl.r * 0.6f, ctl.cy + ctl.y * ctl.r * 0.6f, ctl.r * 0.5f, stroke)
            }
            is Btn -> drawBtn(c, ctl, a)
            is Menu -> {
                stroke.alpha = a; c.drawCircle(ctl.cx, ctl.cy, ctl.r, stroke)
                for (k in -1..1) c.drawLine(ctl.cx - ctl.r * 0.42f, ctl.cy + k * ctl.r * 0.3f, ctl.cx + ctl.r * 0.42f, ctl.cy + k * ctl.r * 0.3f, stroke)
            }
        }
    }

    private fun drawBtn(c: Canvas, b: Btn, a: Int) {
        if (b.pillW > 0) {
            val r = RectF(b.cx - b.pillW / 2, b.cy - b.pillH / 2, b.cx + b.pillW / 2, b.cy + b.pillH / 2)
            fill.alpha = if (b.down) (a * 0.75f).toInt() else a / 6
            c.drawRoundRect(r, b.pillH / 2, b.pillH / 2, fill)
            stroke.alpha = a; c.drawRoundRect(r, b.pillH / 2, b.pillH / 2, stroke)
            text.textSize = min(b.pillH * 0.42f, 14 * dp); text.alpha = a
            text.color = if (b.down) Color.BLACK else Color.WHITE; text.alpha = a
            c.drawText(b.label, b.cx, b.cy + text.textSize * 0.36f, text)
        } else {
            fill.alpha = if (b.down) (a * 0.75f).toInt() else a / 6
            c.drawCircle(b.cx, b.cy, b.r, fill)
            stroke.alpha = a; c.drawCircle(b.cx, b.cy, b.r, stroke)
            text.textSize = b.r * (if (b.label.length > 1) 0.62f else 0.8f)
            text.color = if (b.down) Color.BLACK else Color.WHITE; text.alpha = a
            c.drawText(b.label, b.cx, b.cy + text.textSize * 0.36f, text)
        }
        text.color = Color.WHITE
    }

    private val arm = Path()
    private fun drawDpad(c: Canvas, d: Dpad, a: Int) {
        val r = d.r; val t = r * 0.36f
        arm.reset()
        arm.addRoundRect(RectF(d.cx - t, d.cy - r, d.cx + t, d.cy + r), t * 0.4f, t * 0.4f, Path.Direction.CW)
        arm.addRoundRect(RectF(d.cx - r, d.cy - t, d.cx + r, d.cy + t), t * 0.4f, t * 0.4f, Path.Direction.CW)
        arm.fillType = Path.FillType.WINDING
        fill.alpha = a / 6; c.drawPath(arm, fill)
        stroke.alpha = a; c.drawCircle(d.cx, d.cy, r * 1.08f, stroke.apply { alpha = a / 3 })
        stroke.alpha = a
        // outline of the cross
        val o = Path()
        o.moveTo(d.cx - t, d.cy - r); o.lineTo(d.cx + t, d.cy - r); o.lineTo(d.cx + t, d.cy - t); o.lineTo(d.cx + r, d.cy - t)
        o.lineTo(d.cx + r, d.cy + t); o.lineTo(d.cx + t, d.cy + t); o.lineTo(d.cx + t, d.cy + r); o.lineTo(d.cx - t, d.cy + r)
        o.lineTo(d.cx - t, d.cy + t); o.lineTo(d.cx - r, d.cy + t); o.lineTo(d.cx - r, d.cy - t); o.lineTo(d.cx - t, d.cy - t); o.close()
        c.drawPath(o, stroke)
        fill.alpha = (a * 0.75f).toInt()
        if (d.dy < 0) c.drawRect(d.cx - t, d.cy - r, d.cx + t, d.cy - t, fill)
        if (d.dy > 0) c.drawRect(d.cx - t, d.cy + t, d.cx + t, d.cy + r, fill)
        if (d.dx < 0) c.drawRect(d.cx - r, d.cy - t, d.cx - t, d.cy + t, fill)
        if (d.dx > 0) c.drawRect(d.cx + t, d.cy - t, d.cx + r, d.cy + t, fill)
    }

    // ---------- touch ----------

    private fun buzz() { if (haptics) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY) }

    private fun press(ctl: Ctl, x: Float, y: Float) {
        when (ctl) {
            is Btn -> { if (!ctl.down) { ctl.down = true; listener.onKey(ctl.key, true); buzz() } }
            is Dpad -> moveDpad(ctl, x, y)
            is Stick -> moveStick(ctl, x, y)
            is Menu -> { buzz(); listener.onMenu() }
        }
    }

    private fun release(ctl: Ctl) {
        when (ctl) {
            is Btn -> if (ctl.down && owner.values.none { it === ctl }) { ctl.down = false; listener.onKey(ctl.key, false) }
            is Dpad -> { ctl.dx = 0; ctl.dy = 0; listener.onDpad(0f, 0f) }
            is Stick -> { ctl.x = 0f; ctl.y = 0f; listener.onStick(ctl.right, 0f, 0f) }
            is Menu -> {}
        }
    }

    private fun moveDpad(d: Dpad, x: Float, y: Float) {
        val dx = x - d.cx; val dy = y - d.cy
        var nx = 0; var ny = 0
        if (hypot(dx, dy) > d.r * 0.18f) {
            val ang = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble()))
            val sector = ((ang + 360 + 22.5) % 360 / 45).toInt() // 0 = right, going clockwise
            nx = when (sector) { 0, 1, 7 -> 1; 3, 4, 5 -> -1; else -> 0 }
            ny = when (sector) { 1, 2, 3 -> 1; 5, 6, 7 -> -1; else -> 0 }
        }
        if (nx != d.dx || ny != d.dy) {
            if (nx != 0 || ny != 0) buzz()
            d.dx = nx; d.dy = ny
            listener.onDpad(nx.toFloat(), ny.toFloat())
        }
    }

    private fun moveStick(s: Stick, x: Float, y: Float) {
        var nx = (x - s.cx) / s.r; var ny = (y - s.cy) / s.r
        val m = hypot(nx, ny)
        if (m > 1f) { nx /= m; ny /= m }
        s.x = nx; s.y = ny
        listener.onStick(s.right, nx, ny)
    }

    private fun find(x: Float, y: Float): Ctl? =
        ctls.filter { it.hit(x, y) }.minByOrNull { hypot(x - it.cx, y - it.cy) }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                val ctl = find(e.getX(i), e.getY(i))
                if (ctl == null) {
                    // let the first finger reach the game underneath (touch screens)
                    if (e.actionMasked == MotionEvent.ACTION_DOWN) return false
                } else {
                    owner[e.getPointerId(i)] = ctl
                    press(ctl, e.getX(i), e.getY(i))
                }
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) {
                    val id = e.getPointerId(i); val ctl = owner[id] ?: continue
                    val x = e.getX(i); val y = e.getY(i)
                    when (ctl) {
                        is Dpad -> moveDpad(ctl, x, y)
                        is Stick -> moveStick(ctl, x, y)
                        is Btn -> if (ctl.face && !ctl.hit(x, y)) {
                            // slide between face buttons
                            val other = find(x, y)
                            if (other is Btn && other.face) { owner[id] = other; release(ctl); press(other, x, y) }
                        }
                        else -> {}
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                val ids = if (e.actionMasked == MotionEvent.ACTION_CANCEL) (0 until e.pointerCount).map { e.getPointerId(it) }
                          else listOf(e.getPointerId(e.actionIndex))
                for (id in ids) { val ctl = owner.remove(id) ?: continue; release(ctl) }
            }
        }
        invalidate()
        return true
    }

    /** Lets go of everything, e.g. when the pause menu opens. */
    fun releaseAll() {
        val held = owner.values.toList(); owner.clear(); held.forEach { release(it) }
        ctls.filterIsInstance<Btn>().forEach { if (it.down) { it.down = false; listener.onKey(it.key, false) } }
        invalidate()
    }

}
