package com.crossbar.retro

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.text.TextPaint
import android.text.TextUtils
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

class XItem(
    val title: String,
    val sub: String,
    val icon: String,
    val dim: Boolean = false,
    val options: (() -> Unit)? = null,
    val action: () -> Unit,
)

class XColumn(val id: String, val name: String, val icon: String, val items: List<XItem>, val empty: String? = null, val dim: Boolean = false)

/**
 * The cross bar: consoles run left to right, the selected console's items run top to bottom.
 * Items before the selected one slide up above the bar, like the original.
 */
class XmbView(ctx: Context) : View(ctx) {

    private val dp = resources.displayMetrics.density
    var theme: XTheme = Themes.all[0]
        set(v) { field = v; bgShader = null; invalidate() }
    var waves = true
        set(v) { field = v; invalidate() }

    var columns: List<XColumn> = emptyList()
        private set
    var col = 0
        private set
    private val rows = HashMap<String, Int>()
    private var colPos = 0f
    private var rowPos = 0f

    private var toastText: String? = null
    private var toastUntil = 0L
    var progress: Float? = null
        set(v) { field = v; invalidate() }
    var progressText: String = ""

    private val light = Typeface.create("sans-serif-light", Typeface.NORMAL)
    private val regular = Typeface.create("sans-serif", Typeface.NORMAL)
    private val iconP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        maskFilter = BlurMaskFilter(6 * resources.displayMetrics.density, BlurMaskFilter.Blur.NORMAL) }
    private val titleP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; typeface = light }
    private val subP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = light; textSize = 13.5f * dp }
    private val labelP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; typeface = regular; textSize = 14 * dp; letterSpacing = 0.03f
        setShadowLayer(8 * dp, 0f, 0f, Color.argb(160, 0, 0, 0)) }
    private val clockP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; typeface = light; textSize = 16 * dp; letterSpacing = 0.04f }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private var bgShader: Shader? = null
    private val clockFmt = SimpleDateFormat("EEE d/M   HH:mm", Locale.getDefault())

    // layout metrics, recomputed on size change
    private var cell = 0f
    private var iconSize = 0f
    private var anchorX = 0f
    private var barY = 0f
    private var rowH = 0f
    private var selY = 0f
    private var textX = 0f

    var onSelectionChanged: (() -> Unit)? = null

    fun setColumns(list: List<XColumn>, keepId: String? = null) {
        val prevId = keepId ?: columns.getOrNull(col)?.id
        columns = list
        val idx = list.indexOfFirst { it.id == prevId }
        if (idx >= 0) col = idx
        col = col.coerceIn(0, max(0, list.size - 1))
        list.forEach { c -> rows[c.id] = (rows[c.id] ?: 0).coerceIn(0, max(0, c.items.size - 1)) }
        invalidate()
    }

    fun jumpTo(id: String, row: Int = 0) {
        val idx = columns.indexOfFirst { it.id == id }
        if (idx >= 0) { col = idx; rows[id] = row; rowPos = row.toFloat(); invalidate() }
    }

    fun toast(msg: String) { toastText = msg; toastUntil = SystemClock.uptimeMillis() + 3800; invalidate() }

    private fun curCol() = columns.getOrNull(col)
    private fun curRow() = curCol()?.let { rows[it.id] ?: 0 } ?: 0
    fun current(): XItem? = curCol()?.items?.getOrNull(curRow())

    // ---------- navigation ----------

    fun command(cmd: String) {
        when (cmd) {
            "left" -> selectCol(col - 1)
            "right" -> selectCol(col + 1)
            "up" -> selectRow(curRow() - 1)
            "down" -> selectRow(curRow() + 1)
            "ok" -> current()?.action?.invoke()
            "opts" -> current()?.options?.invoke()
        }
    }

    private fun selectCol(i: Int) {
        val n = i.coerceIn(0, max(0, columns.size - 1))
        if (n != col) {
            col = n; rowPos = curRow().toFloat()
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            onSelectionChanged?.invoke(); invalidate()
        }
    }

    private fun selectRow(r: Int) {
        val c = curCol() ?: return
        val n = r.coerceIn(0, max(0, c.items.size - 1))
        if (n != curRow()) {
            rows[c.id] = n
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            onSelectionChanged?.invoke(); invalidate()
        }
    }

    // ---------- layout ----------

    override fun setPadding(left: Int, top: Int, right: Int, bottom: Int) {
        super.setPadding(left, top, right, bottom)
        if (width > 0) onSizeChanged(width, height, width, height)
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val landscape = w > h
        cell = (if (landscape) 104 else 86) * dp
        iconSize = (if (landscape) 50 else 44) * dp
        anchorX = if (landscape) max(w * 0.2f, 120 * dp) else max(20 * dp, paddingLeft.toFloat()) + cell / 2f
        barY = paddingTop + if (landscape) h * 0.25f else min(h * 0.19f, 170 * dp)
        rowH = (if (landscape) 62 else 68) * dp
        selY = barY + iconSize * 0.75f + 58 * dp
        textX = anchorX + 40 * dp
        bgShader = null
    }

    private fun itemY(d: Float): Float {
        val above = barY - iconSize * 0.75f - 44 * dp
        return when {
            d >= 0f -> selY + d * rowH + if (d > 0f) min(d, 1f) * 10 * dp else 0f
            d > -1f -> above + (selY - above) * (d + 1f)
            else -> above + (d + 1f) * rowH
        }
    }

    // ---------- drawing ----------

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val w = width.toFloat(); val h = height.toFloat()

        // background
        if (bgShader == null) bgShader = RadialGradient(w * 0.3f, h * 0.05f, max(w, h) * 1.05f,
            intArrayOf(theme.top, theme.bottom), floatArrayOf(0f, 0.75f), Shader.TileMode.CLAMP)
        fill.shader = bgShader; c.drawRect(0f, 0f, w, h, fill); fill.shader = null
        if (waves) drawWaves(c, now / 1000f)

        // animate toward the selection
        val dragC = dragColOffset; val dragR = dragRowOffset
        colPos += (col - dragC - colPos) * 0.22f
        val targetRow = curRow() - dragR
        rowPos += (targetRow - rowPos) * 0.25f
        if (abs(col - dragC - colPos) < 0.002f) colPos = col - dragC
        if (abs(targetRow - rowPos) < 0.002f) rowPos = targetRow

        // clock
        val clock = clockFmt.format(Date(System.currentTimeMillis()))
        val cw = clockP.measureText(clock)
        val cx = w - max(20 * dp, paddingRight.toFloat()) - cw
        val cy = paddingTop + 34 * dp
        c.drawText(clock, cx, cy, clockP)
        fill.shader = LinearGradient(cx - 70 * dp, 0f, cx - 12 * dp, 0f, Color.TRANSPARENT, Color.argb(150, 255, 255, 255), Shader.TileMode.CLAMP)
        c.drawRect(cx - 70 * dp, cy - 6 * dp, cx - 12 * dp, cy - 5 * dp, fill); fill.shader = null

        drawItems(c)
        drawBar(c)
        drawToast(c, now)

        val settling = abs(col - dragC - colPos) > 0 || abs(targetRow - rowPos) > 0
        if (waves || settling || toastText != null || progress != null) postInvalidateOnAnimation()
        else postInvalidateDelayed(15_000) // keep the clock fresh
    }

    private fun drawWaves(c: Canvas, s: Float) {
        val w = width.toFloat(); val h = height.toFloat()
        val base = h * 0.6f
        val wr = Color.red(theme.wave); val wg = Color.green(theme.wave); val wb = Color.blue(theme.wave)
        for (k in 0 until 3) {
            val amp = h * (0.07f + k * 0.025f); val freq = 1.6f + k * 0.55f; val sp = 0.18f + k * 0.07f; val ph = k * 1.7f
            val top = Path(); val band = Path()
            var x = 0f
            val step = 10 * dp
            while (x <= w + step) {
                val u = x / w
                val y = base + sin(u * freq * Math.PI + s * sp + ph).toFloat() * amp + sin(u * 5.3 + s * sp * 1.7 + ph).toFloat() * amp * 0.25f
                if (x == 0f) { top.moveTo(x, y); band.moveTo(x, y) } else { top.lineTo(x, y); band.lineTo(x, y) }
                x += step
            }
            x -= step
            while (x >= 0f) {
                val u = x / w
                val y = base + 26 * dp + k * 10 * dp + sin(u * freq * Math.PI + s * sp + ph + 0.5).toFloat() * amp * 0.9f + sin(u * 4.1 + s * sp * 1.3).toFloat() * amp * 0.2f
                band.lineTo(x, y); x -= step
            }
            band.close()
            fill.shader = LinearGradient(0f, base - amp, 0f, base + amp + 40 * dp,
                intArrayOf(Color.argb(0, wr, wg, wb), Color.argb((26 - k * 5), wr, wg, wb), Color.argb(0, wr, wg, wb)), null, Shader.TileMode.CLAMP)
            c.drawPath(band, fill); fill.shader = null
            iconP.alpha = 60 - k * 15; iconP.strokeWidth = dp
            c.drawPath(top, iconP)
        }
        iconP.alpha = 255
    }

    private fun drawBar(c: Canvas) {
        columns.forEachIndexed { i, column ->
            val x = anchorX + (i - colPos) * cell
            if (x < -cell || x > width + cell) return@forEachIndexed
            val dist = abs(i - colPos).coerceAtMost(1f)
            val scale = 1.25f - 0.25f * dist
            val alpha = (255 * (1f - 0.5f * dist)).toInt().let { if (column.dim) it / 2 else it }
            val size = iconSize * scale
            if (dist < 0.5f) { glowP.alpha = (120 * (1 - dist * 2)).toInt(); Icons.draw(c, column.icon, x, barY, size, glowP) }
            iconP.alpha = alpha
            Icons.draw(c, column.icon, x, barY, size, iconP)
            if (dist < 0.5f) {
                labelP.alpha = (255 * (1 - dist * 2)).toInt()
                val lw = labelP.measureText(column.name)
                c.drawText(column.name, x - lw / 2f, barY + size / 2f + 24 * dp, labelP)
            }
        }
        iconP.alpha = 255; labelP.alpha = 255
    }

    private val optRects = HashMap<Int, RectF>()
    private val itemRects = HashMap<Int, RectF>()

    private fun drawItems(c: Canvas) {
        val column = columns.getOrNull(col) ?: return
        optRects.clear(); itemRects.clear()
        // fade the list while the bar is between columns
        val colAlpha = (1f - abs(col - colPos) * 1.6f).coerceIn(0f, 1f)
        if (colAlpha <= 0f) return
        val sel = curRow()
        val textW = width - textX - max(20 * dp, paddingRight.toFloat()) - 52 * dp
        column.items.forEachIndexed { i, item ->
            val d = i - rowPos
            val y = itemY(d)
            if (y < -rowH || y > height + rowH) return@forEachIndexed
            // keep the area just around the bar clear
            if (y > barY - iconSize * 0.75f - 18 * dp && y < barY + iconSize * 0.75f + 38 * dp && i != sel) return@forEachIndexed
            val isSel = i == sel
            val near = (1f - abs(d)).coerceIn(0f, 1f)
            var a = if (d < -0.5f) 0.42f else if (isSel) 1f else 0.72f
            if (item.dim) a *= 0.55f
            a *= colAlpha
            val ic = iconSize * (0.82f + 0.22f * near)
            if (isSel) { glowP.alpha = (110 * a).toInt(); Icons.draw(c, item.icon, anchorX, y, ic, glowP) }
            iconP.alpha = (255 * a).toInt()
            Icons.draw(c, item.icon, anchorX, y, ic, iconP)

            titleP.textSize = (16.5f + 3.5f * near) * dp
            titleP.alpha = (255 * a).toInt()
            if (isSel) titleP.setShadowLayer(12 * dp, 0f, 0f, Color.argb((150 * a).toInt(), 255, 255, 255)) else titleP.clearShadowLayer()
            val title = TextUtils.ellipsize(item.title, titleP, textW, TextUtils.TruncateAt.END).toString()
            val ty = if (isSel) y - 2 * dp else y + titleP.textSize * 0.35f
            c.drawText(title, textX, ty, titleP)
            if (isSel && item.sub.isNotEmpty()) {
                subP.color = Color.argb((165 * a).toInt(), 225, 233, 248)
                val sub = TextUtils.ellipsize(item.sub, subP, textW, TextUtils.TruncateAt.END).toString()
                c.drawText(sub, textX, y + 20 * dp, subP)
            }
            itemRects[i] = RectF(anchorX - iconSize * 0.7f, y - rowH / 2f, width.toFloat(), y + rowH / 2f)
            if (isSel && item.options != null) {
                val ox = width - max(20 * dp, paddingRight.toFloat()) - 22 * dp
                val r = RectF(ox - 22 * dp, y - 22 * dp, ox + 22 * dp, y + 22 * dp)
                iconP.alpha = (90 * a).toInt(); iconP.strokeWidth = dp
                c.drawCircle(ox, y, 20 * dp, iconP)
                fill.color = Color.argb((255 * a).toInt(), 255, 255, 255)
                for (k in -1..1) c.drawCircle(ox + k * 7 * dp, y, 2.2f * dp, fill)
                optRects[i] = r
            }
        }
        if (column.items.size <= 1 && column.empty != null) {
            subP.color = Color.argb((110 * colAlpha).toInt(), 225, 233, 248)
            val y = itemY(1f) + 4 * dp
            val lines = column.empty.split("\n")
            lines.forEachIndexed { k, l -> c.drawText(l, textX, y + k * 20 * dp, subP) }
        }
        titleP.clearShadowLayer(); iconP.alpha = 255
    }

    private fun drawToast(c: Canvas, now: Long) {
        val p = progress
        val text = if (p != null) progressText else toastText?.takeIf { now < toastUntil }
        if (text == null) { toastText = null; return }
        subP.color = Color.WHITE
        val maxW = min(width - 40 * dp, 420 * dp)
        val shown = TextUtils.ellipsize(text, subP, maxW - 48 * dp, TextUtils.TruncateAt.END).toString()
        val tw = subP.measureText(shown)
        val left = max(20 * dp, paddingLeft.toFloat())
        val bottom = height - max(22 * dp, paddingBottom + 14 * dp)
        val r = RectF(left, bottom - 50 * dp, left + tw + 48 * dp, bottom)
        fill.color = Color.argb(215, 6, 12, 26); c.drawRoundRect(r, 8 * dp, 8 * dp, fill)
        iconP.alpha = 45; iconP.strokeWidth = dp; c.drawRoundRect(r, 8 * dp, 8 * dp, iconP); iconP.alpha = 255
        fill.color = theme.wave; c.drawCircle(r.left + 18 * dp, r.centerY(), 4 * dp, fill)
        c.drawText(shown, r.left + 32 * dp, r.centerY() + 5 * dp, subP)
        if (p != null) {
            fill.color = Color.argb(60, 255, 255, 255); c.drawRect(r.left + 12 * dp, r.bottom - 6 * dp, r.right - 12 * dp, r.bottom - 4 * dp, fill)
            fill.color = theme.wave; c.drawRect(r.left + 12 * dp, r.bottom - 6 * dp, r.left + 12 * dp + (r.width() - 24 * dp) * p.coerceIn(0f, 1f), r.bottom - 4 * dp, fill)
        }
    }

    // ---------- touch ----------

    private var downX = 0f; private var downY = 0f; private var downT = 0L
    private var axis = 0 // 0 undecided, 1 horizontal, 2 vertical
    private var dragColOffset = 0f
    private var dragRowOffset = 0f
    private var longPressed = false
    private val longPress = Runnable {
        if (axis == 0) {
            val i = itemRects.entries.firstOrNull { it.value.contains(downX, downY) }?.key
            val item = i?.let { curCol()?.items?.getOrNull(it) }
            if (item?.options != null) {
                longPressed = true
                rows[curCol()!!.id] = i
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                item.options.invoke()
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y; downT = SystemClock.uptimeMillis(); axis = 0; longPressed = false
                postDelayed(longPress, 520)
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - downX; val dy = e.y - downY
                if (axis == 0 && max(abs(dx), abs(dy)) > 12 * dp) { axis = if (abs(dx) > abs(dy)) 1 else 2; removeCallbacks(longPress) }
                if (axis == 1) dragColOffset = (dx / cell).coerceIn(col - columns.size + 1f - 0.3f, col + 0.3f)
                if (axis == 2) { val n = curCol()?.items?.size ?: 1; dragRowOffset = (dy / rowH).coerceIn(curRow() - n + 1f - 0.3f, curRow() + 0.3f) }
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPress)
                val dt = max(1L, SystemClock.uptimeMillis() - downT)
                if (axis == 1) {
                    val vx = (e.x - downX) / dt
                    var steps = dragColOffset.roundToInt()
                    if (steps == 0 && abs(vx) > 0.4f) steps = if (vx > 0) 1 else -1
                    colPos = col - dragColOffset; dragColOffset = 0f
                    selectCol(col - steps)
                } else if (axis == 2) {
                    val vy = (e.y - downY) / dt
                    var steps = dragRowOffset.roundToInt()
                    if (abs(vy) > 0.6f) steps += (vy * 2.5f).toInt()
                    rowPos = curRow() - dragRowOffset; dragRowOffset = 0f
                    selectRow(curRow() - steps)
                } else if (!longPressed && e.actionMasked == MotionEvent.ACTION_UP) tap(e.x, e.y)
                axis = 0; invalidate()
            }
        }
        return true
    }

    private fun tap(x: Float, y: Float) {
        // console icons
        if (abs(y - barY) < iconSize) {
            val i = ((x - anchorX) / cell + colPos).roundToInt()
            if (i in columns.indices && abs(x - (anchorX + (i - colPos) * cell)) < cell / 2) { selectCol(i); return }
        }
        optRects.entries.firstOrNull { it.value.contains(x, y) }?.let { curCol()?.items?.getOrNull(it.key)?.options?.invoke(); return }
        val hit = itemRects.entries.firstOrNull { it.value.contains(x, y) }?.key ?: return
        val column = curCol() ?: return
        rows[column.id] = hit
        invalidate()
        column.items.getOrNull(hit)?.action?.invoke()
    }
}
