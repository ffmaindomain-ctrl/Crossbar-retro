package com.crossbar.retro

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.content.FileProvider
import java.io.File

/** Hands a game to a separate emulator app, the way ES-DE and Daijisho do. */
object ExternalLauncher {

    private fun id(a: ExternalApp) = "${a.pkg}/${a.activity}"

    @Suppress("DEPRECATION")
    private fun exists(ctx: Context, a: ExternalApp): Boolean = try {
        val cn = ComponentName(a.pkg, a.activity)
        if (Build.VERSION.SDK_INT >= 33) ctx.packageManager.getActivityInfo(cn, PackageManager.ComponentInfoFlags.of(0))
        else ctx.packageManager.getActivityInfo(cn, 0)
        true
    } catch (_: Exception) { false }

    /** Installed apps, one entry per package (the first matching activity wins). */
    fun installed(ctx: Context, c: Console): List<ExternalApp> =
        c.external.filter { exists(ctx, it) }.distinctBy { it.pkg }

    fun chosen(ctx: Context, c: Console, prefs: Prefs): ExternalApp? {
        val list = installed(ctx, c)
        return list.firstOrNull { id(it) == prefs.externalApp(c.id) } ?: list.singleOrNull()
    }

    fun remember(prefs: Prefs, c: Console, a: ExternalApp) = prefs.setExternalApp(c.id, id(a))

    /** Returns null on success, or a message to show. */
    fun launch(ctx: Context, a: ExternalApp, game: Game): String? {
        val file = File(game.path)
        if (!file.exists()) return "The game file is missing. Import it again."
        val uri: Uri = try {
            FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", file)
        } catch (_: Exception) { return "This game is stored somewhere the PS2 app cannot be given access to." }

        val intent = Intent().apply {
            component = ComponentName(a.pkg, a.activity)
            if (a.viaView) {
                action = Intent.ACTION_VIEW
                data = uri
            } else {
                action = Intent.ACTION_MAIN
                putExtra("bootPath", uri.toString())
            }
            clipData = ClipData.newRawUri(game.title, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        // the boot path travels as text, so grant the app read access directly too
        try { ctx.grantUriPermission(a.pkg, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
        return try { ctx.startActivity(intent); null }
        catch (_: ActivityNotFoundException) { "${a.name} could not be opened. Try reinstalling it." }
        catch (_: SecurityException) { "${a.name} refused to open the game." }
    }

    fun openPage(ctx: Context, url: String): Boolean = try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (_: Exception) { false }
}
