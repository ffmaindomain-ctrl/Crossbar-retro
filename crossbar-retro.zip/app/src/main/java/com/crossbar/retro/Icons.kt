package com.crossbar.retro

import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF

/** Original line-drawn icons on a 48 x 48 grid, drawn with a single stroke paint. */
object Icons {

    private class B {
        val p = Path()
        fun rect(x: Float, y: Float, w: Float, h: Float, r: Float = 0f) =
            p.addRoundRect(RectF(x, y, x + w, y + h), r, r, Path.Direction.CW)
        fun circle(cx: Float, cy: Float, r: Float) = p.addCircle(cx, cy, r, Path.Direction.CW)
        fun line(vararg pts: Float) {
            p.moveTo(pts[0], pts[1]); var i = 2
            while (i + 1 < pts.size) { p.lineTo(pts[i], pts[i + 1]); i += 2 }
        }
        fun cross(cx: Float, cy: Float, s: Float) { line(cx, cy - s, cx, cy + s); line(cx - s, cy, cx + s, cy) }
        fun arc(l: Float, t: Float, r: Float, b: Float, start: Float, sweep: Float) {
            val a = Path(); a.addArc(RectF(l, t, r, b), start, sweep); p.addPath(a)
        }
    }

    private fun build(id: String): Path = B().apply {
        when (id) {
            "settings" -> { circle(24f, 24f, 6f)
                line(24f, 6f, 24f, 12f); line(24f, 36f, 24f, 42f); line(6f, 24f, 12f, 24f); line(36f, 24f, 42f, 24f)
                line(11.3f, 11.3f, 15.5f, 15.5f); line(32.5f, 32.5f, 36.7f, 36.7f); line(11.3f, 36.7f, 15.5f, 32.5f); line(32.5f, 15.5f, 36.7f, 11.3f) }
            "import" -> { line(24f, 8f, 24f, 29f); line(16f, 21f, 24f, 29f, 32f, 21f); line(8f, 31f, 8f, 40f, 40f, 40f, 40f, 31f) }
            "disc" -> { circle(24f, 24f, 17f); circle(24f, 24f, 4f); arc(11f, 11f, 37f, 37f, 270f, 90f) }
            "ps2" -> { rect(15f, 5f, 18f, 38f, 2f); line(15f, 13f, 33f, 13f); line(19f, 9f, 29f, 9f); circle(24f, 29f, 5f) }
            "psp" -> { rect(4f, 15f, 40f, 18f, 9f); rect(15f, 18f, 18f, 12f, 1f); cross(9f, 24f, 2.2f); circle(39f, 22.5f, 1f); circle(39f, 26f, 1f) }
            "gb" -> { rect(12f, 5f, 24f, 38f, 3f); rect(16f, 9f, 16f, 13f, 1f); cross(17f, 33f, 3f); circle(29f, 34f, 1.6f); circle(33f, 31f, 1.6f) }
            "gbc" -> { rect(12f, 5f, 24f, 38f, 6f); rect(16f, 9f, 16f, 12f, 2f); cross(17f, 32f, 3f); circle(29f, 33f, 1.6f); circle(33f, 30f, 1.6f) }
            "gba" -> { rect(4f, 14f, 40f, 20f, 7f); rect(16f, 17f, 16f, 14f, 1f); cross(9f, 24f, 3f); circle(37f, 25f, 1.5f); circle(40f, 22f, 1.5f) }
            "nds" -> { rect(9f, 4f, 30f, 19f, 2f); rect(14f, 7f, 20f, 13f, 1f); rect(9f, 25f, 30f, 19f, 2f); rect(16f, 28f, 16f, 12f, 1f) }
            "n3ds" -> { rect(8f, 4f, 32f, 19f, 3f); rect(12f, 7f, 24f, 13f, 1f); rect(8f, 25f, 32f, 19f, 3f); rect(17f, 28f, 14f, 11f, 1f); circle(12.5f, 30f, 1.8f); circle(36f, 33f, 1.3f) }
            "vb" -> { rect(6f, 17f, 36f, 15f, 3f); circle(15f, 24.5f, 3f); circle(33f, 24.5f, 3f); line(18f, 32f, 15f, 43f); line(30f, 32f, 33f, 43f) }
            "pokemini" -> { rect(10f, 7f, 28f, 34f, 9f); rect(15f, 12f, 18f, 12f, 1f); circle(18f, 32f, 2.5f); circle(30f, 32f, 2.5f) }
            "gw" -> { rect(4f, 12f, 40f, 24f, 3f); rect(13f, 16f, 22f, 16f, 1f); circle(8.5f, 30f, 1.6f); circle(39.5f, 30f, 1.6f) }
            "sg1000" -> { rect(6f, 18f, 36f, 16f, 1f); line(10f, 28f, 20f, 28f); rect(28f, 14f, 10f, 4f) }
            "sms" -> { rect(6f, 16f, 36f, 18f, 2f); line(14f, 16f, 14f, 12f, 34f, 12f, 34f, 16f); line(11f, 28f, 19f, 28f); line(34f, 25f, 37f, 25f) }
            "md" -> { rect(6f, 20f, 36f, 14f, 7f); circle(24f, 27f, 5f); line(18f, 20f, 18f, 14f, 30f, 14f, 30f, 20f) }
            "gg" -> { rect(3f, 14f, 42f, 20f, 8f); rect(16f, 17f, 16f, 14f, 1f); cross(9f, 24f, 3f); circle(37f, 26f, 1.5f); circle(40f, 23f, 1.5f) }
            "segacd" -> { rect(5f, 21f, 38f, 15f, 2f); circle(24f, 15f, 9f); circle(24f, 15f, 2f); line(10f, 31f, 20f, 31f) }
            "s32x" -> { arc(10f, 14f, 38f, 42f, 180f, 180f); rect(8f, 28f, 32f, 10f, 2f); line(20f, 14.5f, 20f, 8f, 28f, 8f, 28f, 14.5f) }
            "saturn" -> { circle(24f, 24f, 10f)
                val o = Path(); o.addOval(RectF(3f, 17f, 45f, 31f), Path.Direction.CW)
                o.transform(Matrix().apply { setRotate(-18f, 24f, 24f) }); p.addPath(o) }
            "dc" -> { rect(7f, 13f, 34f, 23f, 4f); circle(24f, 24.5f, 6.5f); circle(24f, 24.5f, 2f); line(11f, 32f, 15f, 32f) }
            "cart" -> { line(12f, 6f, 36f, 6f, 36f, 38f, 32f, 42f, 16f, 42f, 12f, 38f, 12f, 6f); rect(16f, 12f, 16f, 12f, 1f); line(18f, 36f, 30f, 36f) }
            "plus" -> { circle(24f, 24f, 17f); cross(24f, 24f, 8f) }
            "chip" -> { rect(13f, 13f, 22f, 22f, 2f)
                for (v in listOf(18f, 24f, 30f)) { line(v, 8f, v, 13f); line(v, 35f, v, 40f); line(8f, v, 13f, v); line(35f, v, 40f, v) } }
            "info" -> { circle(24f, 24f, 17f); line(24f, 22f, 24f, 33f); line(24f, 15f, 24f, 15.6f) }
            "palette" -> { circle(24f, 24f, 17f); circle(16f, 21f, 2.4f); circle(23f, 15f, 2.4f); circle(31f, 18f, 2.4f); circle(30f, 31f, 3.5f) }
            "wave" -> { p.moveTo(4f, 22f); p.cubicTo(12f, 14f, 16f, 30f, 24f, 22f); p.cubicTo(32f, 14f, 36f, 30f, 44f, 22f)
                p.moveTo(4f, 32f); p.cubicTo(12f, 24f, 16f, 40f, 24f, 32f); p.cubicTo(32f, 24f, 36f, 40f, 44f, 32f) }
            "disk" -> { line(10f, 8f, 32f, 8f, 38f, 14f, 38f, 40f, 10f, 40f, 10f, 8f); line(16f, 8f, 16f, 17f, 30f, 17f, 30f, 8f); rect(16f, 27f, 16f, 13f) }
            "trash" -> { line(10f, 14f, 38f, 14f); line(19f, 14f, 19f, 9f, 29f, 9f, 29f, 14f); line(14f, 14f, 16f, 40f, 32f, 40f, 34f, 14f) }
            "pad" -> { rect(5f, 15f, 38f, 19f, 9.5f); cross(14f, 24.5f, 3.5f); circle(32f, 22f, 1.8f); circle(36f, 26.5f, 1.8f) }
            "home" -> { line(8f, 22f, 24f, 9f, 40f, 22f); line(13f, 19f, 13f, 38f, 35f, 38f, 35f, 19f) }
            "lock" -> { rect(12f, 21f, 24f, 19f, 2f); arc(16f, 9f, 32f, 29f, 180f, 180f); line(16f, 19f, 16f, 21f); line(32f, 19f, 32f, 21f) }
            else -> circle(24f, 24f, 16f)
        }
    }.p

    private val cache = HashMap<String, Path>()

    fun draw(c: Canvas, id: String, cx: Float, cy: Float, size: Float, paint: Paint) {
        val path = cache.getOrPut(id) { build(id) }
        c.save()
        c.translate(cx - size / 2f, cy - size / 2f)
        c.scale(size / 48f, size / 48f)
        val w = paint.strokeWidth
        paint.strokeWidth = 1.9f
        c.drawPath(path, paint)
        paint.strokeWidth = w
        c.restore()
    }
}
