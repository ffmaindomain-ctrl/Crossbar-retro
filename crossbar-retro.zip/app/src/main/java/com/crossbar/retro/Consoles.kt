package com.crossbar.retro

import android.content.Context
import java.io.File

/** Touch-control families. Each console picks the one that matches its real pad. */
enum class PadLayout { GB, GBA, NDS, N3DS, VB, POKEMINI, GW, PSX, PS2, PSP, MD, SMS, SATURN, DC, NES, SNES, N64, GC }

/** A separate emulator app the game is handed to (used for PS2). */
data class ExternalApp(val name: String, val pkg: String, val activity: String, val viaView: Boolean)

object Engines {
    val names = mapOf(
        "pcsx_rearmed" to "PCSX-ReARMed  ·  fast, works without BIOS",
        "mednafen_psx" to "Beetle PSX  ·  most accurate, needs a BIOS",
        "swanstation" to "SwanStation  ·  sharp graphics, good compatibility",
        "melonds" to "melonDS", "desmume" to "DeSmuME",
        "yabasanshiro" to "YabaSanshiro", "yabause" to "Yabause",
        "fceumm" to "FCEUmm", "nestopia" to "Nestopia",
        "mupen64plus_next_gles3" to "Mupen64Plus-Next", "parallel_n64" to "ParaLLEl N64",
    )
    fun name(core: String) = names[core] ?: core
}

data class Console(
    val id: String,
    val name: String,
    /** libretro core names to try, first one present in the APK wins */
    val cores: List<String>,
    val exts: List<String>,
    val icon: String,
    val pad: PadLayout,
    /** handhelds play in portrait with the screen on top, home consoles in landscape */
    val portrait: Boolean,
    /** width / height of the picture, used to leave room for the screen in portrait */
    val aspect: Float,
    val disc: Boolean = false,
    val bios: List<String> = emptyList(),
    val biosRequired: Boolean = false,
    /** sub-folder of the system folder the core reads its BIOS from */
    val biosDir: String = "",
    val note: String? = null,
    val external: List<ExternalApp> = emptyList(),
) {
    private fun file(ctx: Context, core: String) = File(ctx.applicationInfo.nativeLibraryDir, "lib${core}_libretro_android.so")

    /** Engines for this console that are in the APK. */
    fun installedCores(ctx: Context) = cores.filter { file(ctx, it).exists() }

    /** The chosen engine if it is installed, otherwise the first one that is. */
    fun coreFile(ctx: Context, preferred: String? = null): File? =
        (listOfNotNull(preferred) + cores).map { file(ctx, it) }.firstOrNull { it.exists() }

    val isExternal get() = external.isNotEmpty()
    fun available(ctx: Context) = isExternal || coreFile(ctx) != null
}

object Consoles {
    val all = listOf(
        Console("psx", "PlayStation", listOf("pcsx_rearmed", "swanstation", "mednafen_psx"),
            listOf("pbp", "chd", "cue", "m3u", "iso", "bin", "img", "ccd", "mdf"),
            "disc", PadLayout.PSX, portrait = false, aspect = 4f / 3f, disc = true,
            bios = listOf("scph5501.bin", "scph1001.bin", "scph7001.bin")),
        Console("ps2", "PlayStation 2", emptyList(),
            listOf("iso", "chd", "cso", "zso", "bin", "cue", "elf", "gz"),
            "ps2", PadLayout.PS2, portrait = false, aspect = 4f / 3f, disc = true,
            note = "Plays in ARMSX2 or NetherSX2 / AetherSX2",
            external = listOf(
                ExternalApp("ARMSX2", "come.nanodata.armsx2", "com.armsx2.MainActivity", viaView = true),
                ExternalApp("ARMSX2", "come.nanodata.armsx2", "kr.co.iefriends.pcsx2.MainActivity", viaView = true),
                ExternalApp("ARMSX2", "com.armsx2", "com.armsx2.MainActivity", viaView = true),
                ExternalApp("ARMSX2 Nightly", "com.armsx2.nightly", "com.armsx2.MainActivity", viaView = true),
                ExternalApp("NetherSX2 / AetherSX2", "xyz.aethersx2.android", "xyz.aethersx2.android.EmulationActivity", viaView = false),
                ExternalApp("NetherSX2 Turnip", "xyz.aethersx2.tturnip", "xyz.aethersx2.android.EmulationActivity", viaView = false),
                ExternalApp("NetherSX2 Turnip Classic", "xyz.aethersx2.cturnip", "xyz.aethersx2.android.EmulationActivity", viaView = false),
            )),
        Console("psp", "PlayStation Portable", listOf("ppsspp"),
            listOf("iso", "cso", "pbp", "elf", "chd"),
            "psp", PadLayout.PSP, portrait = false, aspect = 16f / 9f, disc = true),
        Console("nes", "NES", listOf("fceumm", "nestopia"), listOf("nes", "fds", "unf", "unif"),
            "nes", PadLayout.NES, portrait = false, aspect = 4f / 3f,
            bios = listOf("disksys.rom"), note = "Famicom Disk System games need disksys.rom"),
        Console("snes", "Super Nintendo", listOf("snes9x"), listOf("sfc", "smc", "fig", "swc", "bs"),
            "snes", PadLayout.SNES, portrait = false, aspect = 4f / 3f),
        Console("n64", "Nintendo 64", listOf("mupen64plus_next_gles3", "parallel_n64"), listOf("n64", "z64", "v64"),
            "n64", PadLayout.N64, portrait = false, aspect = 4f / 3f),
        Console("gc", "GameCube", listOf("dolphin"), listOf("iso", "gcm", "gcz", "rvz", "ciso", "dol"),
            "gc", PadLayout.GC, portrait = false, aspect = 4f / 3f, disc = true,
            note = "Experimental. Needs a powerful phone"),
        Console("wii", "Wii", listOf("dolphin"), listOf("wbfs", "iso", "rvz", "gcz", "wad"),
            "wii", PadLayout.GC, portrait = false, aspect = 16f / 9f, disc = true,
            note = "Experimental. Games that need motion controls will not play well"),
        Console("gb", "Game Boy", listOf("gambatte"), listOf("gb"),
            "gb", PadLayout.GB, portrait = true, aspect = 10f / 9f),
        Console("gbc", "Game Boy Color", listOf("gambatte"), listOf("gbc"),
            "gbc", PadLayout.GB, portrait = true, aspect = 10f / 9f),
        Console("gba", "Game Boy Advance", listOf("mgba"), listOf("gba"),
            "gba", PadLayout.GBA, portrait = true, aspect = 3f / 2f,
            bios = listOf("gba_bios.bin")),
        Console("nds", "Nintendo DS", listOf("melonds", "desmume"), listOf("nds"),
            "nds", PadLayout.NDS, portrait = true, aspect = 256f / 384f,
            bios = listOf("bios7.bin", "bios9.bin", "firmware.bin")),
        Console("3ds", "Nintendo 3DS", listOf("citra"), listOf("3ds", "cci", "cxi", "app", "3dsx"),
            "n3ds", PadLayout.N3DS, portrait = true, aspect = 400f / 480f,
            note = "Needs a powerful phone. Games must be decrypted."),
        Console("vb", "Virtual Boy", listOf("mednafen_vb"), listOf("vb", "vboy"),
            "vb", PadLayout.VB, portrait = false, aspect = 384f / 224f),
        Console("pokemini", "Pokémon mini", listOf("pokemini"), listOf("min"),
            "pokemini", PadLayout.POKEMINI, portrait = true, aspect = 96f / 64f,
            bios = listOf("bios.min")),
        Console("gw", "Game & Watch", listOf("gw"), listOf("mgw"),
            "gw", PadLayout.GW, portrait = true, aspect = 4f / 3f),
        Console("sg1000", "SG-1000", listOf("genesis_plus_gx"), listOf("sg"),
            "sg1000", PadLayout.SMS, portrait = false, aspect = 4f / 3f),
        Console("sms", "Master System", listOf("genesis_plus_gx"), listOf("sms"),
            "sms", PadLayout.SMS, portrait = false, aspect = 4f / 3f),
        Console("md", "Mega Drive", listOf("genesis_plus_gx"), listOf("md", "gen", "smd", "bin", "68k", "sgd"),
            "md", PadLayout.MD, portrait = false, aspect = 4f / 3f),
        Console("gg", "Game Gear", listOf("genesis_plus_gx"), listOf("gg"),
            "gg", PadLayout.SMS, portrait = true, aspect = 160f / 144f),
        Console("segacd", "Mega-CD", listOf("genesis_plus_gx"), listOf("chd", "cue", "iso", "bin", "m3u"),
            "segacd", PadLayout.MD, portrait = false, aspect = 4f / 3f, disc = true,
            bios = listOf("bios_CD_U.bin", "bios_CD_E.bin", "bios_CD_J.bin"), biosRequired = true),
        Console("32x", "32X", listOf("picodrive"), listOf("32x"),
            "s32x", PadLayout.MD, portrait = false, aspect = 4f / 3f),
        Console("saturn", "Saturn", listOf("yabasanshiro", "yabause"),
            listOf("chd", "cue", "iso", "ccd", "mds", "m3u"),
            "saturn", PadLayout.SATURN, portrait = false, aspect = 4f / 3f, disc = true,
            bios = listOf("saturn_bios.bin"), note = "Heavy for phones"),
        Console("dc", "Dreamcast", listOf("flycast"), listOf("chd", "cdi", "gdi", "cue", "m3u"),
            "dc", PadLayout.DC, portrait = false, aspect = 4f / 3f, disc = true,
            bios = listOf("dc_boot.bin", "dc_flash.bin"), biosDir = "dc"),
    )

    val byId = all.associateBy { it.id }

    /** Track files that belong to a .cue/.gdi/.ccd sheet rather than being games themselves. */
    private val trackExts = setOf("bin", "img", "raw", "sub", "mdf")
    val sheetExts = setOf("cue", "gdi", "ccd", "m3u", "mds")

    fun ownersOf(ext: String): List<Console> = all.filter { ext in it.exts }

    /** The only console a file can belong to, or null when the user has to choose. */
    fun guess(fileName: String): Console? {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        if (ext in setOf("zip", "7z")) return null
        val owners = ownersOf(ext)
        return if (owners.size == 1) owners[0] else null
    }

    fun isTrack(ext: String) = ext in trackExts
}
