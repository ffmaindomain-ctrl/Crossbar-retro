package com.crossbar.retro

import android.content.Context
import java.io.File

/** Touch-control families. Each console picks the one that matches its real pad. */
enum class PadLayout { GB, GBA, NDS, N3DS, VB, POKEMINI, GW, PSX, PS2, PSP, MD, SMS, SATURN, DC }

data class Console(
    val id: String,
    val name: String,
    /** libretro core names to try, first one present in the APK wins */
    val cores: List<String>,
    val exts: List<String>,
    val icon: String,
    val pad: PadLayout,
    /** handhelds play in portrait with the screen on top, home consoles in landscape */
    val portrait: Boolean,
    /** width / height of the picture, used to leave room for the screen in portrait */
    val aspect: Float,
    val disc: Boolean = false,
    val bios: List<String> = emptyList(),
    val biosRequired: Boolean = false,
    /** sub-folder of the system folder the core reads its BIOS from */
    val biosDir: String = "",
    val note: String? = null,
) {
    fun coreFile(ctx: Context): File? = cores
        .map { File(ctx.applicationInfo.nativeLibraryDir, "lib${it}_libretro_android.so") }
        .firstOrNull { it.exists() }

    fun available(ctx: Context) = coreFile(ctx) != null
}

object Consoles {
    val all = listOf(
        Console("psx", "PlayStation", listOf("pcsx_rearmed"),
            listOf("pbp", "chd", "cue", "m3u", "iso", "bin", "img", "ccd", "mdf"),
            "disc", PadLayout.PSX, portrait = false, aspect = 4f / 3f, disc = true,
            bios = listOf("scph5501.bin", "scph1001.bin", "scph7001.bin")),
        Console("ps2", "PlayStation 2", listOf("play"),
            listOf("iso", "chd", "cso", "bin", "cue", "elf", "isz"),
            "ps2", PadLayout.PS2, portrait = false, aspect = 4f / 3f, disc = true,
            note = "Needs a powerful phone"),
        Console("psp", "PlayStation Portable", listOf("ppsspp"),
            listOf("iso", "cso", "pbp", "elf", "chd"),
            "psp", PadLayout.PSP, portrait = false, aspect = 16f / 9f, disc = true),
        Console("gb", "Game Boy", listOf("gambatte"), listOf("gb"),
            "gb", PadLayout.GB, portrait = true, aspect = 10f / 9f),
        Console("gbc", "Game Boy Color", listOf("gambatte"), listOf("gbc"),
            "gbc", PadLayout.GB, portrait = true, aspect = 10f / 9f),
        Console("gba", "Game Boy Advance", listOf("mgba"), listOf("gba"),
            "gba", PadLayout.GBA, portrait = true, aspect = 3f / 2f,
            bios = listOf("gba_bios.bin")),
        Console("nds", "Nintendo DS", listOf("melonds", "desmume"), listOf("nds"),
            "nds", PadLayout.NDS, portrait = true, aspect = 256f / 384f,
            bios = listOf("bios7.bin", "bios9.bin", "firmware.bin")),
        Console("3ds", "Nintendo 3DS", listOf("citra"), listOf("3ds", "cci", "cxi", "app", "3dsx"),
            "n3ds", PadLayout.N3DS, portrait = true, aspect = 400f / 480f,
            note = "Needs a powerful phone. Games must be decrypted."),
        Console("vb", "Virtual Boy", listOf("mednafen_vb"), listOf("vb", "vboy"),
            "vb", PadLayout.VB, portrait = false, aspect = 384f / 224f),
        Console("pokemini", "Pokémon mini", listOf("pokemini"), listOf("min"),
            "pokemini", PadLayout.POKEMINI, portrait = true, aspect = 96f / 64f,
            bios = listOf("bios.min")),
        Console("gw", "Game & Watch", listOf("gw"), listOf("mgw"),
            "gw", PadLayout.GW, portrait = true, aspect = 4f / 3f),
        Console("sg1000", "SG-1000", listOf("genesis_plus_gx"), listOf("sg"),
            "sg1000", PadLayout.SMS, portrait = false, aspect = 4f / 3f),
        Console("sms", "Master System", listOf("genesis_plus_gx"), listOf("sms"),
            "sms", PadLayout.SMS, portrait = false, aspect = 4f / 3f),
        Console("md", "Mega Drive", listOf("genesis_plus_gx"), listOf("md", "gen", "smd", "bin", "68k", "sgd"),
            "md", PadLayout.MD, portrait = false, aspect = 4f / 3f),
        Console("gg", "Game Gear", listOf("genesis_plus_gx"), listOf("gg"),
            "gg", PadLayout.SMS, portrait = true, aspect = 160f / 144f),
        Console("segacd", "Mega-CD", listOf("genesis_plus_gx"), listOf("chd", "cue", "iso", "bin", "m3u"),
            "segacd", PadLayout.MD, portrait = false, aspect = 4f / 3f, disc = true,
            bios = listOf("bios_CD_U.bin", "bios_CD_E.bin", "bios_CD_J.bin"), biosRequired = true),
        Console("32x", "32X", listOf("picodrive"), listOf("32x"),
            "s32x", PadLayout.MD, portrait = false, aspect = 4f / 3f),
        Console("saturn", "Saturn", listOf("yabasanshiro", "yabause"),
            listOf("chd", "cue", "iso", "ccd", "mds", "m3u"),
            "saturn", PadLayout.SATURN, portrait = false, aspect = 4f / 3f, disc = true,
            bios = listOf("saturn_bios.bin"), note = "Heavy for phones"),
        Console("dc", "Dreamcast", listOf("flycast"), listOf("chd", "cdi", "gdi", "cue", "m3u"),
            "dc", PadLayout.DC, portrait = false, aspect = 4f / 3f, disc = true,
            bios = listOf("dc_boot.bin", "dc_flash.bin"), biosDir = "dc"),
    )

    val byId = all.associateBy { it.id }

    /** Track files that belong to a .cue/.gdi/.ccd sheet rather than being games themselves. */
    private val trackExts = setOf("bin", "img", "raw", "sub", "mdf")
    val sheetExts = setOf("cue", "gdi", "ccd", "m3u", "mds")

    fun ownersOf(ext: String): List<Console> = all.filter { ext in it.exts }

    /** The only console a file can belong to, or null when the user has to choose. */
    fun guess(fileName: String): Console? {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        if (ext in setOf("zip", "7z")) return null
        val owners = ownersOf(ext)
        return if (owners.size == 1) owners[0] else null
    }

    fun isTrack(ext: String) = ext in trackExts
}
