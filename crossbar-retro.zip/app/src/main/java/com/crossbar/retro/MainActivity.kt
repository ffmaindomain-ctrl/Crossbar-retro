package com.crossbar.retro

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ViewGroup
import android.widget.FrameLayout
import kotlin.math.abs

class MainActivity : Activity() {

    private lateinit var lib: Library
    private lateinit var prefs: Prefs
    private lateinit var xmb: XmbView
    private lateinit var sheet: SheetView
    private var importTarget: String? = null
    private var importing = false
    private val ui = Handler(Looper.getMainLooper())

    companion object {
        private const val REQ_GAMES = 11
        private const val REQ_BIOS = 12
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lib = Library.get(this)
        prefs = Prefs(this)
        xmb = XmbView(this)
        sheet = SheetView(this).apply { visibility = android.view.View.GONE }
        val root = FrameLayout(this)
        root.addView(xmb, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(sheet, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        Screen.immersive(this, root) { l, t, r, b -> xmb.setPadding(l, t, r, b) }
        applyTheme()
        refresh()
        val first = Consoles.all.firstOrNull { lib.gamesFor(it.id).isNotEmpty() }
        xmb.jumpTo(first?.id ?: "import")
    }

    override fun onResume() {
        super.onResume()
        Screen.immersive(this, null, null)
        refresh()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) Screen.immersive(this, null, null)
    }

    private fun applyTheme() { xmb.theme = prefs.xtheme; xmb.waves = prefs.waves }

    // ---------- menu content ----------

    private fun refresh(keep: String? = null) {
        val cols = mutableListOf<XColumn>()
        cols += XColumn("settings", "Settings", "settings", settingsItems())
        cols += XColumn("import", "Import", "import", listOf(
            XItem("Import games", "Pick ROM files. The console is worked out from the file type.", "plus") { pickGames(null) },
            XItem("Import BIOS file", lib.installedBios().let { if (it.isEmpty()) "Needed for Mega-CD. Optional for PS1, GBA, DS, Saturn, Dreamcast." else "${it.size} installed" }, "chip") { pickBios() },
            XItem("Supported files", "File types for each console", "info") { showFormats() },
        ))
        for (c in Consoles.all) {
            val ok = c.available(this)
            if (!ok) {
                cols += XColumn(c.id, c.name, c.icon, listOf(
                    XItem("Engine not included", "This build does not have the ${c.name} emulator. Rebuild to add it.", "lock", dim = true) {}
                ), dim = true)
                continue
            }
            val items = mutableListOf(XItem("Add ${c.name} games", c.note ?: c.exts.take(5).joinToString("  ") { ".$it" }, "plus") { pickGames(c.id) })
            lib.gamesFor(c.id).forEach { g ->
                items += XItem(g.title, "${ago(g.lastPlayed)}  ·  ${size(g.size)}", if (c.disc) "disc" else "cart",
                    options = { gameOptions(g) }) { play(g) }
            }
            cols += XColumn(c.id, c.name, c.icon, items,
                empty = "No ${c.name} games yet.\nTap “Add ${c.name} games” to bring them in.")
        }
        xmb.setColumns(cols, keep)
    }

    private fun settingsItems() = listOf(
        XItem("Theme colour", prefs.xtheme.name, "palette") { chooseTheme() },
        XItem("Background waves", if (prefs.waves) "On" else "Off", "wave") { prefs.waves = !prefs.waves; applyTheme(); refresh("settings") },
        XItem("Touch controls", "Opacity ${(prefs.padOpacity * 100).toInt()}%  ·  ${sizeName(prefs.padScale)}  ·  vibration ${if (prefs.haptics) "on" else "off"}", "pad") { touchSettings() },
        XItem("BIOS files", lib.installedBios().joinToString(", ") { it.second.name }.ifEmpty { "None installed" }, "chip") { manageBios() },
        XItem("Storage used", "${lib.games().size} games  ·  ${size(lib.totalSize())}", "disk") { showStorage() },
        XItem("Delete all games", "Removes every imported game from this phone", "trash") { confirmWipe() },
        XItem("About", "What runs here", "info") { showAbout() },
    )

    // ---------- import ----------

    private fun pickGames(target: String?) {
        if (importing) { xmb.toast("Still importing, one moment"); return }
        importTarget = target
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        try { startActivityForResult(i, REQ_GAMES) } catch (_: Exception) { xmb.toast("No file picker found on this phone") }
    }

    private fun pickBios() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
        try { startActivityForResult(i, REQ_BIOS) } catch (_: Exception) { xmb.toast("No file picker found on this phone") }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        val uris = mutableListOf<Uri>()
        data.clipData?.let { cd -> for (i in 0 until cd.itemCount) uris += cd.getItemAt(i).uri }
        if (uris.isEmpty()) data.data?.let { uris += it }
        if (uris.isEmpty()) return
        when (requestCode) {
            REQ_GAMES -> prepareImport(uris)
            REQ_BIOS -> chooseBiosConsole(uris[0])
        }
    }

    private fun prepareImport(uris: List<Uri>) {
        val target = importTarget
        xmb.progress = 0f; xmb.progressText = "Reading files…"
        Thread {
            val items = uris.map { u ->
                val name = lib.displayName(u)
                val ext = name.substringAfterLast('.', "").lowercase()
                val console = target ?: Consoles.guess(name)?.id ?: if (ext == "zip") lib.guessArchive(u) else null
                PendingImport(u, name, console)
            }
            runOnUiThread { xmb.progress = null; resolve(items, 0) }
        }.start()
    }

    /** Asks about each file whose console could not be worked out, then copies everything. */
    private fun resolve(items: List<PendingImport>, from: Int) {
        val i = (from until items.size).firstOrNull { items[it].console == null }
        if (i == null) { runImport(items.filter { it.console != null }); return }
        val it = items[i]
        val ext = it.name.substringAfterLast('.', "").lowercase()
        val owners = Consoles.ownersOf(ext).filter { c -> c.available(this) }.ifEmpty { Consoles.all.filter { c -> c.available(this) } }
        sheet.show(Sheet("Which console is this for?", it.name,
            owners.map { c -> SheetOption(c.name) { it.console = c.id; resolve(items, i + 1) } } +
                SheetOption("Skip this file") { resolve(items, i + 1) },
            onCancel = { resolve(items, i + 1) }))
    }

    private fun runImport(items: List<PendingImport>) {
        if (items.isEmpty()) return
        importing = true
        xmb.progress = 0f
        Thread {
            val added = lib.import(items) { done, total, name ->
                runOnUiThread {
                    xmb.progress = done.toFloat() / total
                    xmb.progressText = if (name.isEmpty()) "Finishing…" else "Importing $name  (${done + 1} of $total)"
                }
            }
            runOnUiThread {
                importing = false
                xmb.progress = null
                refresh()
                val last = added.lastOrNull()
                if (last != null) {
                    xmb.jumpTo(last.console, 1)
                    val c = Consoles.byId[last.console]?.name ?: ""
                    xmb.toast(if (added.size == 1) "Added ${last.title} to $c" else "Added ${added.size} games")
                } else xmb.toast("No playable games found in those files")
            }
        }.start()
    }

    // ---------- BIOS ----------

    private fun chooseBiosConsole(uri: Uri) {
        val name = lib.displayName(uri)
        val withBios = Consoles.all.filter { it.bios.isNotEmpty() }
        val match = withBios.firstOrNull { c -> c.bios.any { it.equals(name, true) } }
        val order = if (match != null) listOf(match) + (withBios - match) else withBios
        sheet.show(Sheet("Which console is this BIOS for?", name, order.map { c ->
            SheetOption(c.name, c.bios.joinToString(" / ")) { chooseBiosName(uri, name, c) }
        }))
    }

    private fun chooseBiosName(uri: Uri, picked: String, c: Console) {
        val exact = c.bios.firstOrNull { it.equals(picked, true) }
        if (exact != null || c.bios.size == 1) { saveBios(uri, c, exact ?: c.bios[0]); return }
        sheet.show(Sheet("Save it as", "The emulator looks for one of these names.", c.bios.map { n -> SheetOption(n) { saveBios(uri, c, n) } }))
    }

    private fun saveBios(uri: Uri, c: Console, name: String) {
        Thread {
            val ok = lib.saveBios(uri, c, name) != null
            runOnUiThread { refresh(); xmb.toast(if (ok) "BIOS saved for ${c.name} as $name" else "Could not read that file") }
        }.start()
    }

    private fun manageBios() {
        val list = lib.installedBios()
        if (list.isEmpty()) {
            sheet.show(Sheet("BIOS files", "None installed. Mega-CD needs one to start. The others run without one, but a real BIOS can improve compatibility.",
                listOf(SheetOption("Import BIOS file") { pickBios() }, SheetOption("Close"))))
            return
        }
        sheet.show(Sheet("BIOS files", "Tap a file to remove it.", list.map { (c, f) ->
            SheetOption(c.name, "${f.name}  ·  ${size(f.length())}") {
                sheet.show(Sheet("Remove ${f.name}?", null, listOf(
                    SheetOption("Remove", danger = true) { f.delete(); refresh(); xmb.toast("BIOS removed") },
                    SheetOption("Keep"))))
            }
        } + SheetOption("Import BIOS file") { pickBios() }))
    }

    // ---------- games ----------

    private fun play(g: Game) {
        val c = Consoles.byId[g.console] ?: return
        if (!c.available(this)) { xmb.toast("The ${c.name} emulator is not in this build"); return }
        if (c.biosRequired && !lib.hasBios(c)) {
            sheet.show(Sheet("${c.name} needs a BIOS", "Import ${c.bios.joinToString(" or ")} from your own console first.",
                listOf(SheetOption("Import BIOS file") { pickBios() }, SheetOption("Not now"))))
            return
        }
        startActivity(Intent(this, GameActivity::class.java).putExtra(GameActivity.EXTRA_GAME, g.id))
    }

    private fun gameOptions(g: Game) {
        val c = Consoles.byId[g.console]
        sheet.show(Sheet(g.title, "${c?.name ?: ""}  ·  ${size(g.size)}", listOf(
            SheetOption("Play") { play(g) },
            SheetOption("Move to another console") {
                sheet.show(Sheet("Move to", null, Consoles.all.filter { it.id != g.console && it.available(this) }.map { t ->
                    SheetOption(t.name) { lib.move(g.id, t.id); refresh(); xmb.toast("Moved to ${t.name}") }
                }))
            },
            SheetOption("Delete", danger = true) {
                sheet.show(Sheet("Delete ${g.title}?", "The game file is removed from this phone. Its saves stay.", listOf(
                    SheetOption("Delete", danger = true) { lib.delete(g.id); refresh(); xmb.toast("Deleted ${g.title}") },
                    SheetOption("Cancel"))))
            },
        )))
    }

    // ---------- settings sheets ----------

    private fun chooseTheme() {
        sheet.show(Sheet("Theme colour", null, Themes.all.mapIndexed { i, t ->
            SheetOption(t.name, if (i == prefs.theme) "Current" else null) { prefs.theme = i; applyTheme(); refresh("settings") }
        }))
    }

    private fun sizeName(s: Float) = when { s < 0.95f -> "small"; s > 1.1f -> "large"; else -> "normal size" }

    private fun touchSettings() {
        sheet.show(Sheet("Touch controls", "Applies to every console. Controls hide on their own when a controller is connected.", listOf(
            SheetOption("Opacity", "${(prefs.padOpacity * 100).toInt()}%") {
                sheet.show(Sheet("Opacity", null, listOf(30, 45, 60, 75, 90).map { p ->
                    SheetOption("$p%") { prefs.padOpacity = p / 100f; refresh("settings") } }))
            },
            SheetOption("Size", sizeName(prefs.padScale)) {
                sheet.show(Sheet("Size", null, listOf("Small" to 0.85f, "Normal" to 1f, "Large" to 1.18f).map { (n, v) ->
                    SheetOption(n) { prefs.padScale = v; refresh("settings") } }))
            },
            SheetOption("Vibration", if (prefs.haptics) "On" else "Off") { prefs.haptics = !prefs.haptics; refresh("settings") },
        )))
    }

    private fun showFormats() {
        sheet.show(Sheet("Supported files", "Zip archives are unpacked on import. Disc games work best as one .chd file; a .cue works if you import it together with its .bin files.",
            Consoles.all.map { c -> SheetOption(c.name, c.exts.joinToString("  ") { ".$it" }) }))
    }

    private fun showStorage() {
        val free = try { StatFs(lib.gamesDir.absolutePath).availableBytes } catch (_: Exception) { 0L }
        sheet.show(Sheet("Storage used", "${size(lib.totalSize())} in games. ${size(free)} free on this phone.",
            Consoles.all.mapNotNull { c ->
                val l = lib.gamesFor(c.id); if (l.isEmpty()) null
                else SheetOption(c.name, "${l.size} game${if (l.size == 1) "" else "s"}  ·  ${size(l.sumOf { it.size })}")
            }.ifEmpty { listOf(SheetOption("No games yet")) }))
    }

    private fun confirmWipe() {
        sheet.show(Sheet("Delete every game?", "${lib.games().size} games will be removed from this phone. BIOS files and saves stay.", listOf(
            SheetOption("Delete all games", danger = true) { lib.deleteAll(); refresh(); xmb.toast("All games deleted") },
            SheetOption("Cancel"))))
    }

    private fun showAbout() {
        val engines = Consoles.all.filter { it.available(this) }.joinToString(", ") { it.name }
        sheet.show(Sheet("Crossbar Retro", "Your games, saves and BIOS files stay on this phone. Emulation runs on open-source libretro engines through LibretroDroid.\n\nIn this build: $engines.",
            listOf(SheetOption("Close"))))
    }

    // ---------- input ----------

    private fun send(cmd: String) { if (!sheet.command(cmd)) { if (cmd != "back") xmb.command(cmd) else finish() } }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        val cmd = when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> "left"
            KeyEvent.KEYCODE_DPAD_RIGHT -> "right"
            KeyEvent.KEYCODE_DPAD_UP -> "up"
            KeyEvent.KEYCODE_DPAD_DOWN -> "down"
            KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_BUTTON_START -> "ok"
            KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE -> "back"
            KeyEvent.KEYCODE_BUTTON_Y, KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_MENU -> "opts"
            else -> return super.onKeyDown(keyCode, event)
        }
        if (cmd == "back" && !sheet.isShowing && keyCode != KeyEvent.KEYCODE_BACK) return true // B on the bar does nothing
        send(cmd); return true
    }

    private var stickDir = ""
    private val repeat = object : Runnable { override fun run() { if (stickDir.isNotEmpty()) { send(stickDir); ui.postDelayed(this, 130) } } }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if (e.source and InputDevice.SOURCE_JOYSTICK != InputDevice.SOURCE_JOYSTICK || e.action != MotionEvent.ACTION_MOVE) return super.onGenericMotionEvent(e)
        val x = e.getAxisValue(MotionEvent.AXIS_X) + e.getAxisValue(MotionEvent.AXIS_HAT_X)
        val y = e.getAxisValue(MotionEvent.AXIS_Y) + e.getAxisValue(MotionEvent.AXIS_HAT_Y)
        val dir = when {
            abs(x) < 0.5f && abs(y) < 0.5f -> ""
            abs(x) > abs(y) -> if (x > 0) "right" else "left"
            else -> if (y > 0) "down" else "up"
        }
        if (dir != stickDir) {
            stickDir = dir; ui.removeCallbacks(repeat)
            if (dir.isNotEmpty()) { send(dir); ui.postDelayed(repeat, 380) }
        }
        return true
    }
}

fun size(b: Long): String {
    var v = b.toDouble(); val u = listOf("B", "KB", "MB", "GB"); var i = 0
    while (v >= 1024 && i < 3) { v /= 1024; i++ }
    return if (i == 0) "$b B" else String.format(java.util.Locale.US, if (v < 10) "%.1f %s" else "%.0f %s", v, u[i])
}

fun ago(t: Long): String {
    if (t == 0L) return "Not played yet"
    val m = (System.currentTimeMillis() - t) / 60000
    if (m < 1) return "Played just now"
    if (m < 60) return "Played $m min ago"
    val h = (m + 30) / 60
    if (h < 24) return "Played $h h ago"
    val d = (h + 12) / 24
    return if (d == 1L) "Played yesterday" else "Played $d days ago"
}
