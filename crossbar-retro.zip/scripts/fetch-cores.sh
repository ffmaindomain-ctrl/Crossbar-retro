#!/usr/bin/env bash
# Downloads the emulator engines (libretro cores, 64-bit ARM) into the app before building.
set -uo pipefail
cd "$(dirname "$0")/.."
OUT=app/src/main/jniLibs/arm64-v8a
mkdir -p "$OUT" app/src/main/assets
TMP=$(mktemp -d)

# 1) Engines tested with LibretroDroid, from the Lemuroid core set (pinned)
LC=https://github.com/Swordfish90/LemuroidCores/raw/fee2e824525daa22bcf318f96127fe43fa8a15ad
for c in pcsx_rearmed ppsspp gambatte mgba melonds citra genesis_plus_gx; do
  if curl -fsSL --retry 3 -o "$OUT/lib${c}_libretro_android.so" "$LC/lemuroid_core_${c}/src/main/jniLibs/arm64-v8a/lib${c}_libretro_android.so"; then
    echo "added $c"
  else
    rm -f "$OUT/lib${c}_libretro_android.so"; echo "::warning::could not download $c"
  fi
done
curl -fsSL --retry 3 -o app/src/main/assets/ppsspp.zip "$LC/assets/ppsspp.zip" || echo "::warning::PSP assets missing"

# 2) The rest from the official libretro build server
BB=https://buildbot.libretro.com/nightly/android/latest/arm64-v8a
for c in mednafen_vb picodrive yabasanshiro yabause flycast pokemini gw play; do
  if curl -fsSL --retry 3 -o "$TMP/$c.zip" "$BB/${c}_libretro_android.so.zip" \
     && unzip -o -q "$TMP/$c.zip" -d "$TMP/$c" \
     && mv "$TMP/$c/${c}_libretro_android.so" "$OUT/lib${c}_libretro_android.so"; then
    echo "added $c"
  else
    echo "::warning::$c is not available from the libretro server; that console will show as not included"
  fi
done

# keep one Saturn engine
[ -f "$OUT/libyabasanshiro_libretro_android.so" ] && rm -f "$OUT/libyabause_libretro_android.so"

echo "Engines in this build:"; ls -la "$OUT"
rm -rf "$TMP"
