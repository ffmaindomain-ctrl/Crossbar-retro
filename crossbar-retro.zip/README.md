# Crossbar Retro

An Android emulator front end with a PS3-style cross-bar menu. Import your own ROMs and BIOS files,
then play with touch controls laid out for each console, or with a Bluetooth controller.

## Consoles

| | Engine |
|---|---|
| PlayStation | PCSX-ReARMed |
| PlayStation 2 | Play! (only if the libretro server has an Android build; needs a strong phone) |
| PlayStation Portable | PPSSPP |
| NES / Famicom Disk System | FCEUmm |
| Super Nintendo | Snes9x |
| Nintendo 64 | Mupen64Plus-Next |
| GameCube, Wii | Dolphin (experimental, only if the libretro server has an Android build) |
| Game Boy, Game Boy Color | Gambatte |
| Game Boy Advance | mGBA |
| Nintendo DS | melonDS |
| Nintendo 3DS | Citra (decrypted games; needs a strong phone) |
| Virtual Boy | Beetle VB |
| Pokémon mini | PokeMini |
| Game & Watch | Game & Watch core (.mgw files) |
| SG-1000, Master System, Mega Drive, Game Gear, Mega-CD | Genesis Plus GX |
| 32X | PicoDrive |
| Saturn | YabaSanshiro |
| Dreamcast | Flycast |

Mega-CD needs a BIOS from your own console. PS1, GBA, DS, Saturn and Dreamcast run without one.

## Building

GitHub builds the APK for you. Every push to `main` runs `.github/workflows/build.yml`, which downloads
the emulator engines, builds a signed APK and publishes it under **Releases**.

The APK is signed with the key in `app/crossbar.keystore`, so each new build installs over the
previous one and keeps your games and saves.

## Where things are kept on the phone

- Games: `Android/data/com.crossbar.retro/files/games`
- Saves and states: `Android/data/com.crossbar.retro/files/saves` and `states`
- BIOS: inside the app's private storage
